import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import admin from "firebase-admin";
import { getFirestore } from "firebase-admin/firestore";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Read config to get projectId and databaseId
  const firebaseConfig = JSON.parse(
    await fs.promises.readFile(path.join(process.cwd(), 'firebase-applet-config.json'), 'utf-8')
  );

  // Initialize Firebase Admin
  try {
    if (!admin.apps.length) {
      admin.initializeApp({
        credential: admin.credential.applicationDefault(),
        projectId: firebaseConfig.projectId
      });
    }
    console.log("Firebase Admin initialized for project:", admin.app().options.projectId);
  } catch (err) {
    console.warn("Firebase Admin initialization warning. Ensure Google Application Credentials are set.");
  }

  app.use(express.json());

  // API Route to change password (MASTER ONLY)
  app.post("/api/admin/change-password", async (req, res) => {
    const { uid, newPassword, adminToken } = req.body;

    try {
      const decodedToken = await admin.auth().verifyIdToken(adminToken);
      const adminUid = decodedToken.uid;

      // Use modular getFirestore with databaseId
      const db = getFirestore(admin.app(), firebaseConfig.firestoreDatabaseId);
      const adminDoc = await db.collection('users').doc(adminUid).get();
      const adminData = adminDoc.data();

      if (!adminData || !adminData.isAdmin) {
        return res.status(403).json({ error: "No permission. User is not a Master Admin." });
      }

      await admin.auth().updateUser(uid, {
        password: newPassword
      });

      res.json({ success: true, message: "Senha alterada com sucesso!" });
    } catch (error: any) {
      console.error("Error changing password:", error);
      res.status(500).json({ error: error.message || "Unknown error" });
    }
  });

  // API Route to Delete User (MASTER ONLY)
  app.post("/api/admin/delete-user", async (req, res) => {
    const { uid, adminToken } = req.body;

    try {
      const decodedToken = await admin.auth().verifyIdToken(adminToken);
      const adminUid = decodedToken.uid;
      const db = getFirestore(admin.app(), firebaseConfig.firestoreDatabaseId);
      const adminDoc = await db.collection('users').doc(adminUid).get();
      const adminData = adminDoc.data();

      if (!adminData || !adminData.isAdmin) {
        return res.status(403).json({ error: "Sem permissão." });
      }

      // 1. Delete from Authentication
      await admin.auth().deleteUser(uid);

      // 2. Delete from Firestore (users collection)
      await db.collection('users').doc(uid).delete();

      // Note: Full tenant data cleanup could be added here if needed

      res.json({ success: true, message: "Usuário excluído com sucesso!" });
    } catch (error: any) {
      console.error("Error deleting user:", error);
      res.status(500).json({ error: error.message || "Erro ao excluir usuário" });
    }
  });

  // API Route to Migrate all users to CPF-based email (MASTER ONLY)
  app.post("/api/admin/migrate-users", async (req, res) => {
    const { adminToken } = req.body;

    try {
      const decodedToken = await admin.auth().verifyIdToken(adminToken);
      const adminUid = decodedToken.uid;
      
      // Use modular getFirestore with databaseId
      const db = getFirestore(admin.app(), firebaseConfig.firestoreDatabaseId);
      const adminDoc = await db.collection('users').doc(adminUid).get();
      const adminData = adminDoc.data();

      if (!adminData || !adminData.isAdmin) {
        return res.status(403).json({ error: "No permission." });
      }

      const usersSnapshot = await db.collection('users').get();
      const results = { success: 0, skipped: 0, errors: 0 };

      for (const doc of usersSnapshot.docs) {
        const userData = doc.data();
        if (userData.isAdmin) {
          results.skipped++;
          continue;
        }

        const pureCpf = userData.cpf.replace(/\D/g, '');
        const targetAuthEmail = `${pureCpf}@sistema.com`;

        try {
          // Update Auth Email
          await admin.auth().updateUser(userData.uid, {
            email: targetAuthEmail
          });
          
          // Update Firestore record as well
          await doc.ref.update({ authEmail: targetAuthEmail });
          
          results.success++;
        } catch (err: any) {
          console.error(`Error migrating user ${userData.uid}:`, err);
          results.errors++;
        }
      }

      res.json({ success: true, results });
    } catch (error: any) {
      console.error("Migration error:", error);
      res.status(500).json({ error: error.message || "Unknown error" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
