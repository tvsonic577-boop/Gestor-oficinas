# Security Specification - Produção Moderna SaaS

## 1. Data Invariants
- A User must have a status (pending/approved/blocked).
- Only an Admin can approve/block users.
- Tenants can only access data if their status is 'approved'.
- All service/employee/advance data must belong to a `tenantId`.
- CPF must be unique (enforced at app level for now, or via document ID).

## 2. The "Dirty Dozen" Payloads (Denial Expected)
1. Register with `isAdmin: true`.
2. Register with `status: 'approved'`.
3. Read another tenant's employee list.
4. Update a service belonging to another tenant.
5. Create a service with a fake `tenantId`.
6. Admin-only: Approve oneself.
7. Access data while status is 'pending'.
8. Access data while status is 'blocked'.
9. Update `balance` of an employee directly (should be done via system logic, though technically hard without cloud functions, rules can at least check keys).
10. Delete a user profile as a non-admin.
11. List all users as a regular approved user.
12. Create a service with a negative `totalValue`.

## 3. Test Runner (Draft)
```typescript
// firestore.rules.test.ts (Conceptual)
// ... tests for each payload above ...
```
