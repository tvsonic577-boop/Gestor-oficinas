import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Wrench, 
  Users, 
  Wallet, 
  Clock, 
  CheckCircle2, 
  LayoutDashboard, 
  PlusCircle, 
  Settings,
  ChevronRight,
  TrendingDown,
  Phone,
  User,
  CreditCard,
  MapPin,
  ClipboardList,
  Archive,
  X,
  UserPlus,
  Lock,
  RefreshCw,
  ExternalLink,
  MessageSquare,
  ShieldCheck,
  ShieldAlert,
  UserCheck,
  UserX,
  LogOut,
  Eye,
  EyeOff,
  Trash2,
  ArrowUpRight
} from 'lucide-react';
import { auth, db, firebaseConfig } from './firebase';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  onAuthStateChanged,
  signOut,
  sendPasswordResetEmail,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider
} from 'firebase/auth';
import { 
  doc, 
  setDoc, 
  getDoc, 
  onSnapshot, 
  collection, 
  query, 
  where,
  updateDoc,
  addDoc,
  deleteDoc,
  orderBy,
  getDocs
} from 'firebase/firestore';

// --- Types ---
type ServiceStatus = 'Pendente' | 'Em Produção' | 'Finalizado' | 'Entregue';

interface UserData {
  uid: string;
  email?: string;
  cpf: string;
  name: string;
  phone?: string;
  status: 'pending' | 'approved' | 'blocked';
  isAdmin: boolean;
  role?: 'master' | 'admin' | 'employee';
  tenantId?: string;
  employeeId?: string;
  createdAt: string;
}

interface Employee {
  id: string;
  name: string;
  cpf?: string;
  password?: string;
  balance: number;
}

interface Service {
  id: string;
  clientName: string;
  cpf: string;
  phone: string;
  address: string;
  description: string;
  totalValue: number;
  commissionValue: number;
  expenses?: { description: string; value: number; createdAt: string }[];
  status: ServiceStatus;
  commissionStatus?: 'pending' | 'paid';
  responsibleId?: string;
  createdAt: string;
  deliveryDate?: string;
  downPayment?: number;
}

interface Transaction {
  id: string;
  description: string;
  type: 'entrada' | 'saida';
  value: number;
  date: string;
  createdAt: string;
}

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  alert(`ERRO NO FIRESTORE: ${errInfo.operationType} em ${errInfo.path}. Verifique o console para detalhes.`);
  throw new Error(JSON.stringify(errInfo));
}

interface CPFMapping {
  tenantId: string;
  employeeId: string;
}

interface AdvancePayment {
  id: string;
  employeeId: string;
  value: number;
  description: string;
  date: string;
}

// --- Mock Data ---
const INITIAL_EMPLOYEES: Employee[] = [];
const INITIAL_SERVICES: Service[] = [];

// --- Constants ---
const TABS = [
  { id: 'producao', label: 'PRODUÇÃO', icon: LayoutDashboard },
  { id: 'funcionarios', label: 'FUNCIONÁRIOS', icon: Users },
  { id: 'administracao', label: 'HISTÓRICO', icon: Archive },
  { id: 'faturamento', label: 'FATURAMENTO', icon: Wallet },
  { id: 'caixa', label: 'CAIXA', icon: ArrowUpRight },
  { id: 'meu-extrato', label: 'MEU EXTRATO', icon: CreditCard },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'producao' | 'funcionarios' | 'administracao' | 'faturamento' | 'caixa' | 'master' | 'meu-extrato' | null>('producao');
  const [currentUser, setCurrentUser] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  
  // Login/Register state
  const [loginCpf, setLoginCpf] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [registerName, setRegisterName] = useState('');
  const [registerCpf, setRegisterCpf] = useState('');
  const [registerPhone, setRegisterPhone] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');
  const [registerConfirmPassword, setRegisterConfirmPassword] = useState('');

  // Main Data
  const [services, setServices] = useState<Service[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [advances, setAdvances] = useState<AdvancePayment[]>([]);
  const [allUsers, setAllUsers] = useState<UserData[]>([]); // For Master Admin
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [showPassword, setShowPassword] = useState(false);
  const [employeeCPFLogin, setEmployeeCPFLogin] = useState('');
  const [isEmployeeLogin, setIsEmployeeLogin] = useState(false);

  const handleEmployeeLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!employeeCPFLogin || !loginPassword) {
      alert('POR FAVOR, PREENCHA CPF E SENHA.');
      return;
    }

    setIsAuthLoading(true);
    try {
      const cleanCPF = employeeCPFLogin.replace(/\D/g, '');
      const authEmail = `emp_${cleanCPF}@sistema.com`;
      
      let userCred;
      try {
        // 1. Tenta logar primeiro
        userCred = await signInWithEmailAndPassword(auth, authEmail, loginPassword);
      } catch (loginErr: any) {
        // 2. Se não existir, verificamos no banco e tentamos "auto-criar"
        if (loginErr.code === 'auth/user-not-found' || loginErr.code === 'auth/invalid-credential') {
          const mappingRef = doc(db, 'cpf_mappings', cleanCPF);
          const mappingSnap = await getDoc(mappingRef);
          
          if (mappingSnap.exists()) {
            const { tenantId, employeeId } = mappingSnap.data();
            
            // Verificação direta no Firestore (permitida pelas novas regras para isSignedIn() ou via login anônimo temporário se necessário)
            // Para não depender de regras antes de logar, usamos uma abordagem resiliente
            const employeeDoc = await getDoc(doc(db, 'tenants', tenantId, 'employees', employeeId));
            
            if (employeeDoc.exists()) {
              const employeeData = employeeDoc.data();
              if (employeeData.password === loginPassword) {
                // Senha confere no banco! Vamos tentar registrar este usuário no Auth.
                try {
                  userCred = await createUserWithEmailAndPassword(auth, authEmail, loginPassword);
                } catch (createErr: any) {
                  if (createErr.code === 'auth/admin-restricted-operation') {
                    throw new Error('ERRO DE CONFIGURAÇÃO: O cadastro de usuários está desativado no Firebase Console. Ative "Email/Password" e "Enable create (sign up)".');
                  }
                  throw createErr;
                }
              } else {
                throw new Error('SENHA INCORRETA.');
              }
            } else {
              throw new Error('DADOS DO FUNCIONÁRIO NÃO ENCONTRADOS.');
            }
          } else {
            throw new Error('CPF NÃO CADASTRADO NO SISTEMA.');
          }
        } else {
          throw loginErr;
        }
      }

      const cleanCPF_final = employeeCPFLogin.replace(/\D/g, '');
      const mappingRef = doc(db, 'cpf_mappings', cleanCPF_final);
      const mappingSnap = await getDoc(mappingRef);
      
      if (mappingSnap.exists()) {
        const { tenantId, employeeId } = mappingSnap.data() as { tenantId: string; employeeId: string };
        const employeeDoc = await getDoc(doc(db, 'tenants', tenantId, 'employees', employeeId));
        const employeeData = employeeDoc.data() as Employee;

        const userData: UserData = {
          uid: userCred.user.uid,
          email: authEmail,
          cpf: cleanCPF_final,
          name: employeeData.name || 'FUNCIONÁRIO',
          status: 'approved',
          isAdmin: false,
          role: 'employee',
          tenantId,
          employeeId,
          createdAt: new Date().toISOString()
        } as UserData;

        await setDoc(doc(db, 'users', userCred.user.uid), userData);
        setCurrentUser(userData);
        setActiveTab('meu-extrato');
      }
    } catch (error: any) {
      console.error("Erro no portal do funcionário:", error);
      alert(error.message || 'ERRO AO ACESSAR O PORTAL.');
      await auth.signOut();
    } finally {
      setIsAuthLoading(false);
    }
  };

  // Modals state
  const [showNewServiceModal, setShowNewServiceModal] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [showNewEmployeeModal, setShowNewEmployeeModal] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [assigningServiceId, setAssigningServiceId] = useState<string | null>(null);
  const [launchingValeEmployeeId, setLaunchingValeEmployeeId] = useState<string | null>(null);
  const [viewingStatementEmployeeId, setViewingStatementEmployeeId] = useState<string | null>(null);
  const [editingUser, setEditingUser] = useState<UserData | null>(null);
  const [showAdminNewUserModal, setShowAdminNewUserModal] = useState(false);
  const [showChangePasswordModal, setShowChangePasswordModal] = useState(false);
  const [showChangeUserPasswordModal, setShowChangeUserPasswordModal] = useState(false);
  const [isMigrating, setIsMigrating] = useState(false);
  const [targetUserForPasswordChange, setTargetUserForPasswordChange] = useState<UserData | null>(null);
  const [newUserPassword, setNewUserPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [adminNewUser, setAdminNewUser] = useState({
    name: '',
    email: '',
    cpf: '',
    phone: '',
    password: ''
  });
  const [newService, setNewService] = useState<Partial<Service>>({
    clientName: '', cpf: '', phone: '', address: '', description: '', totalValue: undefined, commissionValue: undefined, status: 'Pendente', downPayment: undefined
  });
  const [commissionType, setCommissionType] = useState<'value' | 'percent'>('value');
  const [commissionPercent, setCommissionPercent] = useState<number | undefined>(undefined);

  const [newEmployeeName, setNewEmployeeName] = useState('');
  const [newEmployeeCPF, setNewEmployeeCPF] = useState('');
  const [newEmployeePassword, setNewEmployeePassword] = useState('');
  const [transactionType, setTransactionType] = useState<'entrada' | 'saida'>('saida');
  const [transactionDescription, setTransactionDescription] = useState('');
  const [transactionValue, setTransactionValue] = useState<number | undefined>(undefined);
  const [valeAmount, setValeAmount] = useState<number | undefined>(undefined);
  const [expenseDescription, setExpenseDescription] = useState('');
  const [expenseValue, setExpenseValue] = useState<number | undefined>(undefined);
  const [addingExpenseServiceId, setAddingExpenseServiceId] = useState<string | null>(null);
  const [valeDescription, setValeDescription] = useState('Vale / Adiantamento');
  
  // History filters
  const [filterStartDate, setFilterStartDate] = useState('');
  const [filterEndDate, setFilterEndDate] = useState('');
  const [filterEmployeeId, setFilterEmployeeId] = useState('all');

  // Faturamento filters
  const [faturamentoSearch, setFaturamentoSearch] = useState('');
  const [faturamentoStartDate, setFaturamentoStartDate] = useState('');
  const [faturamentoEndDate, setFaturamentoEndDate] = useState('');

  // --- Auth & Data Effects ---
  useEffect(() => {
    let unsubscribeSnapshot: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      if (user) {
        // Escuta em tempo real para o documento do usuário logado
        unsubscribeSnapshot = onSnapshot(doc(db, 'users', user.uid), async (userDoc) => {
          if (userDoc.exists()) {
            const data = userDoc.data() as UserData;
            // Reconhecimento Master Forçado para o seu CPF
            if (data.cpf === '02988906157' && (!data.isAdmin || data.status !== 'approved')) {
              await updateDoc(doc(db, 'users', user.uid), { isAdmin: true, status: 'approved' });
            } else {
              setCurrentUser({ ...data, uid: user.uid });
            }
          } else {
            // Se o usuário Auth existe mas o doc no banco sumiu, e for o master, recriamos
            if (user.email === '02988906157@sistema.com') {
               const masterData: UserData = {
                 uid: user.uid,
                 cpf: '02988906157',
                 name: 'ADMIN MASTER',
                 status: 'approved',
                 isAdmin: true,
                 createdAt: new Date().toISOString()
               };
               await setDoc(doc(db, 'users', user.uid), masterData);
               setCurrentUser(masterData);
            } else {
              setCurrentUser(null);
            }
          }
          setLoading(false);
        });
      } else {
        setCurrentUser(null);
        if (unsubscribeSnapshot) {
          unsubscribeSnapshot();
          unsubscribeSnapshot = null;
        }
        setLoading(false);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeSnapshot) unsubscribeSnapshot();
    };
  }, []);

  // Real-time subscriptions for approved users
  useEffect(() => {
    if (!currentUser || currentUser.status !== 'approved') {
      setServices([]);
      setEmployees([]);
      setAdvances([]);
      setTransactions([]);
      return;
    }

    // Lógica para Funcionário
    if (currentUser.role === 'employee' && currentUser.tenantId) {
      const qServices = query(
        collection(db, 'tenants', currentUser.tenantId, 'services'),
        where('responsibleId', '==', currentUser.employeeId)
      );
      const unsubServices = onSnapshot(qServices, (snapshot) => {
        setServices(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Service)));
      });

      const qAdvances = query(
        collection(db, 'tenants', currentUser.tenantId, 'advances'),
        where('employeeId', '==', currentUser.employeeId)
      );
      const unsubAdvances = onSnapshot(qAdvances, (snapshot) => {
        setAdvances(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as AdvancePayment)));
      });

      // Busca dados básicos do funcionário
      getDoc(doc(db, 'tenants', currentUser.tenantId, 'employees', currentUser.employeeId)).then(snap => {
        if (snap.exists()) {
          const data = snap.data() as Employee;
          setEmployees([{ ...data, id: snap.id }]);
        }
      });

      return () => {
        unsubServices();
        unsubAdvances();
      };
    }

    // Lógica para Admin/Master
    if (currentUser.isAdmin || currentUser.role === 'admin' || currentUser.role === 'master' || !currentUser.role) {
      const tenantId = currentUser.tenantId || currentUser.uid;
      const qServices = query(collection(db, 'tenants', tenantId, 'services'), orderBy('createdAt', 'desc'));
      const unsubServices = onSnapshot(qServices, (snapshot) => {
        setServices(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Service)));
      });

      const qEmployees = query(collection(db, 'tenants', tenantId, 'employees'));
      const unsubEmployees = onSnapshot(qEmployees, (snapshot) => {
        setEmployees(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Employee)));
      });

      const qAdvances = query(collection(db, 'tenants', tenantId, 'advances'));
      const unsubAdvances = onSnapshot(qAdvances, (snapshot) => {
        setAdvances(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as AdvancePayment)));
      });

      const qTransactions = query(collection(db, 'tenants', tenantId, 'transactions'), orderBy('createdAt', 'desc'));
      const unsubTransactions = onSnapshot(qTransactions, (snapshot) => {
        setTransactions(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Transaction)));
      });

      return () => {
        unsubServices();
        unsubEmployees();
        unsubAdvances();
        unsubTransactions();
      };
    }
  }, [currentUser]);

  // Real-time users list for Master Admin
  useEffect(() => {
    if (!currentUser || !currentUser.isAdmin) {
      setAllUsers([]);
      return;
    }

    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      setAllUsers(snapshot.docs.map(d => ({ uid: d.id, ...d.data() } as UserData)));
    });

    return () => unsubUsers();
  }, [currentUser]);

  const [isAuthLoading, setIsAuthLoading] = useState(false);

  // --- Auth handlers ---
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsAuthLoading(true);
    try {
      const pureCpf = loginCpf.replace(/\D/g, '');
      const email = `${pureCpf}@sistema.com`;
      await signInWithEmailAndPassword(auth, email, loginPassword);
    } catch (error: any) {
      console.error("Erro no login:", error);
      alert('Erro no login: CPF ou senha incorretos. Verifique se você já criou sua conta.');
    } finally {
      setIsAuthLoading(false);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (newPassword !== confirmNewPassword) {
      alert('AS SENHAS NÃO CONFEREM!');
      return;
    }

    if (newPassword.length < 6) {
      alert('A SENHA DEVE TER NO MÍNIMO 6 CARACTERES!');
      return;
    }

    try {
      if (!auth.currentUser) throw new Error("Usuário não autenticado");
      
      await updatePassword(auth.currentUser, newPassword);
      alert('SENHA ATUALIZADA COM SUCESSO!');
      setShowChangePasswordModal(false);
      setNewPassword('');
      setConfirmNewPassword('');
    } catch (error: any) {
      console.error("Erro ao atualizar senha:", error);
      if (error.code === 'auth/requires-recent-login') {
        alert('POR SEGURANÇA, PARECE QUE VOCÊ ESTÁ LOGADO HÁ MUITO TEMPO. POR FAVOR, FAÇA LOGOUT E LOGIN NOVAMENTE PARA MUDAR A SENHA.');
      } else {
        alert('ERRO AO ATUALIZAR SENHA: ' + (error.message || 'Erro desconhecido'));
      }
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (registerPassword !== registerConfirmPassword) {
      alert('As senhas não conferem!');
      return;
    }
    setIsAuthLoading(true);
    try {
      const pureCpf = registerCpf.replace(/\D/g, '');
      const email = `${pureCpf}@sistema.com`;
      
      // Criar usuário no Auth
      const userCred = await createUserWithEmailAndPassword(auth, email, registerPassword);
      
      const userData: UserData = {
        uid: userCred.user.uid,
        email: userCred.user.email || undefined,
        cpf: pureCpf,
        name: registerName,
        phone: registerPhone,
        status: pureCpf === '02988906157' ? 'approved' : 'pending',
        isAdmin: pureCpf === '02988906157', 
        createdAt: new Date().toISOString()
      };

      // Salvar NO BANCO DE DADOS (Firestore)
      await setDoc(doc(db, 'users', userCred.user.uid), userData);
      
      setCurrentUser(userData);
      alert('Cadastro realizado com sucesso! Bem-vindo ao sistema.');
    } catch (error: any) {
      console.error("Erro no cadastro:", error);
      alert('Erro no cadastro. Este CPF pode já estar em uso ou os dados são inválidos.');
    } finally {
      setIsAuthLoading(false);
    }
  };

  const handleSignOut = () => signOut(auth);

  const handleUpdateUserStatus = async (uid: string, status: 'approved' | 'blocked' | 'pending') => {
    try {
      await updateDoc(doc(db, 'users', uid), { status });
    } catch (error) {
      console.error("Erro ao atualizar status:", error);
      alert('Erro ao atualizar acesso.');
    }
  };

  const handleDeleteUser = async (uid: string) => {
    if (!window.confirm('TEM CERTEZA QUE DESEJA EXCLUIR ESTE USUÁRIO? ESSA AÇÃO REMOVERÁ O ACESSO DE LOGIN E TODOS OS DADOS DO BANCO.')) return;
    try {
      const adminToken = await auth.currentUser?.getIdToken();
      if (!adminToken) throw new Error("Não foi possível obter o token de administrador.");

      const response = await fetch('/api/admin/delete-user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          uid,
          adminToken
        }),
      });

      const result = await response.json();

      if (response.ok) {
        alert('USUÁRIO E ACESSO EXCLUÍDOS COM SUCESSO!');
      } else {
        throw new Error(result.error || 'Erro ao excluir usuário');
      }
    } catch (error: any) {
      console.error("Erro ao excluir usuário:", error);
      alert('ERRO AO EXCLUIR USUÁRIO: ' + (error.message || 'Erro desconhecido'));
    }
  };

  const handleChangeUserPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!targetUserForPasswordChange || !newUserPassword) return;

    if (newUserPassword.length < 6) {
      alert('A SENHA DEVE TER NO MÍNIMO 6 CARACTERES!');
      return;
    }

    try {
      const adminToken = await auth.currentUser?.getIdToken();
      if (!adminToken) throw new Error("Não foi possível obter o token de administrador.");

      const response = await fetch('/api/admin/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          uid: targetUserForPasswordChange.uid,
          newPassword: newUserPassword,
          adminToken: adminToken
        }),
      });

      const result = await response.json();

      if (response.ok) {
        alert('SENHA DO CLIENTE ATUALIZADA COM SUCESSO!');
        setShowChangeUserPasswordModal(false);
        setTargetUserForPasswordChange(null);
        setNewUserPassword('');
      } else {
        throw new Error(result.error || 'Erro desconhecido ao mudar senha');
      }
    } catch (error: any) {
      console.error("Erro ao mudar senha do cliente:", error);
      alert('ERRO AO MUDAR SENHA: ' + (error.message || 'Erro desconhecido'));
    }
  };

  const handleMigrateOldUsers = async () => {
    if (!window.confirm("DESEJA ATUALIZAR TODOS OS USUÁRIOS ANTIGOS PARA O NOVO FORMATO DE LOGIN POR CPF?")) return;
    
    setIsMigrating(true);
    try {
      const adminToken = await auth.currentUser?.getIdToken();
      if (!adminToken) throw new Error("Não foi possível obter o token de administrador.");

      const response = await fetch('/api/admin/migrate-users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminToken }),
      });

      const result = await response.json();

      if (response.ok) {
        alert(`MIGRAÇÃO CONCLUÍDA!\nSucesso: ${result.results.success}\nPulados: ${result.results.skipped}\nErros: ${result.results.errors}`);
      } else {
        throw new Error(result.error || 'Erro na migração');
      }
    } catch (error: any) {
      console.error("Erro na migração:", error);
      alert('ERRO NA MIGRAÇÃO: ' + (error.message || 'Erro desconhecido'));
    } finally {
      setIsMigrating(false);
    }
  };

  const handleAdminResetPassword = async (email: string) => {
    if (!window.confirm(`DESEJA ENVIAR UM E-MAIL DE REDEFINIÇÃO DE SENHA PARA: ${email}?`)) return;
    try {
      await sendPasswordResetEmail(auth, email);
      alert('E-mail de redefinição enviado com sucesso!');
    } catch (error) {
      console.error("Erro ao enviar reset:", error);
      alert('Erro ao enviar e-mail de reset. Verifique se o e-mail é válido.');
    }
  };

  const handleAdminCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // Import dynamic to avoid polluting main bundle more than needed
      const { initializeApp: initSecondary } = await import('firebase/app');
      const { getAuth: getSecondaryAuth, createUserWithEmailAndPassword: createSecondaryUser, signOut: signSecondaryOut } = await import('firebase/auth');
      const { deleteApp } = await import('firebase/app');
      
      // Secondary app to create user without logging out the admin
      const secondaryAppName = `secondary-registration-${Date.now()}`;
      const secondaryApp = initSecondary(firebaseConfig, secondaryAppName);
      const secondaryAuth = getSecondaryAuth(secondaryApp);
      
      try {
        const pureCpf = adminNewUser.cpf.replace(/\D/g, '');
        const authEmail = `${pureCpf}@sistema.com`;
        
        let userUid = '';
        try {
          const userCred = await createSecondaryUser(secondaryAuth, authEmail, adminNewUser.password);
          userUid = userCred.user.uid;
        } catch (authError: any) {
          if (authError.code === 'auth/email-already-in-use') {
            // Se já existe no Auth mas falhou antes no Firestore, tentamos logar para pegar o UID e completar
            const { signInWithEmailAndPassword: signInSecondary } = await import('firebase/auth');
            const userCred = await signInSecondary(secondaryAuth, authEmail, adminNewUser.password);
            userUid = userCred.user.uid;
          } else {
            throw authError;
          }
        }
        
        await setDoc(doc(db, 'users', userUid), {
          uid: userUid,
          email: adminNewUser.email, // Salvamos o email real no Firestore
          authEmail: authEmail,      // Guardamos o email de login para referência
          name: adminNewUser.name,
          cpf: pureCpf,
          phone: adminNewUser.phone,
          status: 'approved',
          isAdmin: false,
          createdAt: new Date().toISOString()
        });

        await signSecondaryOut(secondaryAuth);
        await deleteApp(secondaryApp);
        
        setShowAdminNewUserModal(false);
        setAdminNewUser({ name: '', email: '', cpf: '', phone: '', password: '' });
        alert('USUÁRIO CADASTRADO E LIBERADO COM SUCESSO!');
      } catch (innerError: any) {
        // Garantir que a app secundária seja deletada mesmo se houver erro no cadastro
        await deleteApp(secondaryApp);
        
        if (innerError.code === 'auth/email-already-in-use') {
          alert('ERRO: ESTE E-MAIL JÁ ESTÁ SENDO USADO POR OUTRO USUÁRIO (E TEM SENHA DIFERENTE)!');
        } else if (innerError.code === 'auth/wrong-password') {
          alert('ERRO: ESTE E-MAIL JÁ EXISTE NO SISTEMA COM OUTRA SENHA!');
        } else if (innerError.code === 'auth/weak-password') {
          alert('ERRO: A SENHA PRECISA TER NO MÍNIMO 6 CARACTERES!');
        } else if (innerError.code === 'auth/invalid-email') {
          alert('ERRO: E-MAIL INVÁLIDO!');
        } else {
          throw innerError;
        }
      }
    } catch (error: any) {
      console.error("Erro ao cadastrar usuário via Master:", error);
      alert('ERRO AO CADASTRAR: ' + (error.message || 'Erro desconhecido'));
    }
  };

  const handleUpdateUserDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    try {
      await updateDoc(doc(db, 'users', editingUser.uid), {
        name: editingUser.name,
        phone: editingUser.phone || '',
        cpf: editingUser.cpf
      });
      setEditingUser(null);
      alert('Dados atualizados com sucesso!');
    } catch (error) {
      console.error("Erro ao atualizar usuário:", error);
      alert('Erro ao atualizar dados.');
    }
  };

  // --- Logic handlers (using Firestore) ---
  const updateStatus = async (serviceId: string, newStatus: ServiceStatus) => {
    if (!currentUser) return;
    const service = services.find(s => s.id === serviceId);
    if (!service) return;

    const tenantId = currentUser.tenantId || currentUser.uid;

    // Quando o serviço é finalizado/entregue
    const isNowFinalized = (newStatus === 'Finalizado' || newStatus === 'Entregue') && 
                           (service.status !== 'Finalizado' && service.status !== 'Entregue');
    
    const isNowDelivered = (newStatus === 'Entregue' && service.status !== 'Entregue');

    await updateDoc(doc(db, 'tenants', tenantId, 'services', serviceId), {
      status: newStatus,
      deliveryDate: isNowFinalized ? new Date().toISOString().split('T')[0] : service.deliveryDate || null,
      commissionStatus: isNowFinalized ? 'pending' : (service.commissionStatus || 'pending')
    });

    // Se foi entregue, lançamos o RESTANTE do valor no caixa (Valor Total - Entrada/Sinal)
    if (isNowDelivered) {
      const remainingValue = (Number(service.totalValue) || 0) - (Number(service.downPayment) || 0);
      if (remainingValue > 0) {
        await addDoc(collection(db, 'tenants', tenantId, 'transactions'), {
          description: `RESTANTE SERV: ${service.clientName.toUpperCase()}`,
          type: 'entrada',
          value: remainingValue,
          date: new Date().toISOString().split('T')[0],
          createdAt: new Date().toISOString(),
          serviceId: service.id
        });
      }
    }
  };

  const handleMarkAsPaid = async (serviceId: string) => {
    if (!currentUser || !currentUser.uid) {
      alert("Sessão expirada. Recarregue a página.");
      return;
    }
    
    // Buscar o serviço mais atualizado diretamente do estado
    const service = services.find(s => s.id === serviceId);
    if (!service) {
      alert("Serviço não encontrado.");
      return;
    }

    if (service.commissionStatus === 'paid') return;
    
    try {
      const tenantId = currentUser.tenantId || currentUser.uid;
      // 1. Atualizar Saldo do Funcionário (se houver um responsável)
      if (service.responsibleId && service.responsibleId !== 'none') {
        const emp = employees.find(e => e.id === service.responsibleId);
        if (emp) {
          const currentBalance = Number(emp.balance) || 0;
          const commission = Number(service.commissionValue) || 0;
          
          await updateDoc(doc(db, 'tenants', tenantId, 'employees', emp.id), {
            balance: currentBalance + commission
          });
        }
      }

      // 2. Marcar comissão como paga no serviço
      await updateDoc(doc(db, 'tenants', tenantId, 'services', serviceId), {
        commissionStatus: 'paid'
      });

      // 3. Lançar saída no caixa automaticamente
      await addDoc(collection(db, 'tenants', tenantId, 'transactions'), {
        description: `PAGTO COMISSÃO: ${service.clientName.toUpperCase()}`,
        type: 'saida',
        value: Number(service.commissionValue) || 0,
        date: new Date().toISOString().split('T')[0],
        createdAt: new Date().toISOString(),
        serviceId: service.id
      });
      
      alert("PAGAMENTO REALIZADO COM SUCESSO! O saldo do colaborador e o caixa foram atualizados.");
    } catch (error) {
      console.error("Erro no pagamento:", error);
      alert("Falha ao processar pagamento. Tente novamente.");
    }
  };

  const handleLaunchVale = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !launchingValeEmployeeId || !valeAmount) return;

    const tenantId = currentUser.tenantId || currentUser.uid;
    const newAdvanceData = {
      employeeId: launchingValeEmployeeId,
      value: valeAmount,
      description: valeDescription,
      date: new Date().toISOString().split('T')[0],
      tenantId: tenantId
    };

    const emp = employees.find(e => e.id === launchingValeEmployeeId);
    await addDoc(collection(db, 'tenants', tenantId, 'advances'), newAdvanceData);
    
    // Lançar saída no caixa automaticamente
    await addDoc(collection(db, 'tenants', tenantId, 'transactions'), {
      description: `VALE/ADIANT: ${emp?.name.toUpperCase() || 'COLABORADOR'}`,
      type: 'saida',
      value: valeAmount,
      date: new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString(),
      employeeId: launchingValeEmployeeId
    });
    
    if (emp) {
      await updateDoc(doc(db, 'tenants', tenantId, 'employees', emp.id), {
        balance: emp.balance - valeAmount
      });
    }

    setLaunchingValeEmployeeId(null);
    setValeAmount(undefined);
    setValeDescription('Vale / Adiantamento');
  };

  const assignEmployee = async (serviceId: string, employeeId: string) => {
    if (!currentUser) return;
    const tenantId = currentUser.tenantId || currentUser.uid;
    await updateDoc(doc(db, 'tenants', tenantId, 'services', serviceId), {
      responsibleId: employeeId || null
    });
    setAssigningServiceId(null);
  };

  const handleEditEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEmployee || !currentUser) return;
    const tenantId = currentUser.tenantId || currentUser.uid;
    const cleanCPF = editingEmployee.cpf?.replace(/\D/g, '') || '';
    
    await updateDoc(doc(db, 'tenants', tenantId, 'employees', editingEmployee.id), {
      name: editingEmployee.name.toUpperCase(),
      cpf: cleanCPF,
      password: editingEmployee.password || ''
    });

    // Atualiza mapeamento se o CPF existia
    if (cleanCPF) {
      await setDoc(doc(db, 'cpf_mappings', cleanCPF), {
        tenantId: tenantId,
        employeeId: editingEmployee.id
      });
    }

    setEditingEmployee(null);
  };

  const handleDeleteEmployee = async (id: string) => {
    if (!currentUser) return;
    const tenantId = currentUser.tenantId || currentUser.uid;
    const emp = employees.find(e => e.id === id);
    if (!emp) return;

    if (confirm(`DESEJA EXCLUIR O FUNCIONÁRIO ${emp.name.toUpperCase()} DEFINITIVAMENTE?`)) {
      try {
        // 1. Limpar mapeamento de CPF
        if (emp.cpf) {
          const cleanCPF = emp.cpf.replace(/\D/g, '');
          if (cleanCPF) {
            await deleteDoc(doc(db, 'cpf_mappings', cleanCPF));
          }
        }

        // 2. Excluir funcionário
        await deleteDoc(doc(db, 'tenants', tenantId, 'employees', id));
        
        alert('FUNCIONÁRIO EXCLUÍDO COM SUCESSO.');
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `tenants/${tenantId}/employees/${id}`);
      }
    }
  };

  const handleDeleteService = async (serviceId: string) => {
    if (!currentUser || !currentUser.uid) {
      alert("Sessão inválida. Tente recarregar a página.");
      return;
    }
    
    const tenantId = currentUser.tenantId || currentUser.uid;
    const service = services.find(s => s.id === serviceId);
    if (!service) return;

    if (confirm('Tem certeza que deseja excluir este serviço definitivamente? O valor da comissão será estornado do saldo do funcionário.')) {
      try {
        // Se o serviço ja foi PAGO, retira a comissão do saldo do funcionário ao excluir
        if (service.commissionStatus === 'paid' && service.responsibleId && service.responsibleId !== 'self') {
          const emp = employees.find(e => e.id === service.responsibleId);
          if (emp) {
            await updateDoc(doc(db, 'tenants', tenantId, 'employees', emp.id), {
              balance: emp.balance - (service.commissionValue || 0)
            });
          }
        }
        
        await deleteDoc(doc(db, 'tenants', tenantId, 'services', serviceId));
      } catch (error) {
        console.error("Erro ao deletar serviço:", error);
        alert("Erro ao excluir serviço.");
      }
    }
  };

  const handleDeleteAdvance = async (advanceId: string) => {
    if (!currentUser || !currentUser.uid) return;
    const tenantId = currentUser.tenantId || currentUser.uid;
    
    const advance = advances.find(a => a.id === advanceId);
    if (!advance) return;

    if (confirm('Tem certeza que deseja excluir este vale? O valor será devolvido ao saldo do funcionário.')) {
      try {
        const emp = employees.find(e => e.id === advance.employeeId);
        if (emp) {
          await updateDoc(doc(db, 'tenants', tenantId, 'employees', emp.id), {
            balance: emp.balance + advance.value
          });
        }
        await deleteDoc(doc(db, 'tenants', tenantId, 'advances', advanceId));
      } catch (error) {
        console.error("Erro ao deletar vale:", error);
        alert("Erro ao excluir vale.");
      }
    }
  };

  const calculateCommission = (total: number | undefined, percent: number | undefined) => {
    if (total && percent) {
      const val = (total * percent) / 100;
      setNewService(prev => ({ ...prev, commissionValue: val }));
    }
  };

  const formatCurrency = (value: any) => {
    const num = typeof value === 'number' ? value : Number(value) || 0;
    return num.toLocaleString('pt-BR', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  };

  const handleAddEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmployeeName || !newEmployeeCPF || !newEmployeePassword || !currentUser) {
      alert('PREENCHA TODOS OS CAMPOS.');
      return;
    }
    
    setIsAuthLoading(true);
    try {
      const cleanCPF = newEmployeeCPF.replace(/\D/g, '');
      const tenantId = currentUser.tenantId || currentUser.uid;

      // Apenas salvamos o funcionário. O Auth será criado no primeiro login dele
      // para evitar problemas de Admin Restricted ou necessidade de app secundário.
      const employeeData = {
        name: newEmployeeName.toUpperCase(),
        cpf: cleanCPF,
        password: newEmployeePassword,
        balance: 0,
        tenantId: tenantId
      };

      const docRef = await addDoc(collection(db, 'tenants', tenantId, 'employees'), employeeData);
      
      await setDoc(doc(db, 'cpf_mappings', cleanCPF), {
        tenantId: tenantId,
        employeeId: docRef.id
      });

      setShowNewEmployeeModal(false);
      setNewEmployeeName('');
      setNewEmployeeCPF('');
      setNewEmployeePassword('');
      alert('FUNCIONÁRIO CADASTRADO COM SUCESSO! Ele já pode acessar o portal com CPF e Senha.');
    } catch (error: any) {
      console.error("Erro ao adicionar funcionário:", error);
      alert('ERRO AO CADASTRAR: ' + (error.message || 'Erro desconhecido'));
    } finally {
      setIsAuthLoading(false);
    }
  };

  const handleAddService = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    const tenantId = currentUser.tenantId || currentUser.uid;
    const serviceToAdd = {
      ...newService,
      totalValue: newService.totalValue || 0,
      downPayment: newService.downPayment || 0,
      commissionValue: newService.commissionValue || 0,
      createdAt: new Date().toISOString().split('T')[0],
      tenantId: tenantId
    };
    
    try {
      const docRef = await addDoc(collection(db, 'tenants', tenantId, 'services'), serviceToAdd);

      // Auto-lançamento no caixa se houver entrada/sinal
      if (serviceToAdd.downPayment > 0) {
        await addDoc(collection(db, 'tenants', tenantId, 'transactions'), {
          description: `SINAL: ${serviceToAdd.clientName.toUpperCase()}`,
          type: 'entrada',
          value: serviceToAdd.downPayment,
          date: new Date().toISOString().split('T')[0],
          createdAt: new Date().toISOString(),
          serviceId: docRef.id // Vínculo opcional
        });
      }

      setShowNewServiceModal(false);
      setNewService({ clientName: '', cpf: '', phone: '', address: '', description: '', totalValue: undefined, downPayment: undefined, commissionValue: undefined, status: 'Pendente' });
      setCommissionPercent(undefined);
    } catch (error) {
      console.error("Erro ao adicionar serviço:", error);
      alert("ERRO AO SALVAR SERVIÇO.");
    }
  };

  const handleEditService = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingService || !currentUser) return;
    
    try {
      const tenantId = currentUser.tenantId || currentUser.uid;
      const serviceRef = doc(db, 'tenants', tenantId, 'services', editingService.id);
      const oldService = services.find(s => s.id === editingService.id);
      const newDownPayment = Number(editingService.downPayment) || 0;

      await updateDoc(serviceRef, {
        clientName: editingService.clientName,
        cpf: editingService.cpf,
        phone: editingService.phone,
        address: editingService.address,
        description: editingService.description,
        totalValue: Number(editingService.totalValue) || 0,
        downPayment: newDownPayment,
        commissionValue: Number(editingService.commissionValue) || 0
      });

      // Se o valor de entrada mudou e é maior que o anterior, lançamos a diferença no caixa?
      // Ou simplificamos: se não tinha entrada e agora tem, lança.
      if (oldService && newDownPayment > (oldService.downPayment || 0)) {
        const diff = newDownPayment - (oldService.downPayment || 0);
        await addDoc(collection(db, 'tenants', tenantId, 'transactions'), {
          description: `ENTRADA ADICIONAL: ${editingService.clientName.toUpperCase()}`,
          type: 'entrada',
          value: diff,
          date: new Date().toISOString().split('T')[0],
          createdAt: new Date().toISOString(),
          serviceId: editingService.id
        });
      }
      
      setEditingService(null);
    } catch (error) {
      console.error("Erro ao editar serviço:", error);
      alert("ERRO AO ATUALIZAR SERVIÇO.");
    }
  };

  const handleHomeClick = () => {
    setActiveTab('producao');
    setShowNewServiceModal(false);
    setShowNewEmployeeModal(false);
    setEditingEmployee(null);
    setAssigningServiceId(null);
    setLaunchingValeEmployeeId(null);
    setViewingStatementEmployeeId(null);
    setAddingExpenseServiceId(null);
  };

  const handleAddExpense = async (serviceId: string) => {
    if (!currentUser || !expenseDescription || !expenseValue) return;
    
    const service = services.find(s => s.id === serviceId);
    if (!service) return;

    const tenantId = currentUser.tenantId || currentUser.uid;
    const newExpense = {
      description: expenseDescription,
      value: expenseValue,
      createdAt: new Date().toISOString().split('T')[0]
    };

    const updatedExpenses = [...(service.expenses || []), newExpense];
    
    const serviceRef = doc(db, 'tenants', tenantId, 'services', serviceId);
    await updateDoc(serviceRef, {
      expenses: updatedExpenses
    });

    setExpenseDescription('');
    setExpenseValue(undefined);
    setAddingExpenseServiceId(null);
  };

  const handleRemoveExpense = async (serviceId: string, index: number) => {
    if (!currentUser) return;
    
    const service = services.find(s => s.id === serviceId);
    if (!service || !service.expenses) return;

    const tenantId = currentUser.tenantId || currentUser.uid;
    const updatedExpenses = service.expenses.filter((_, i) => i !== index);
    
    const serviceRef = doc(db, 'tenants', tenantId, 'services', serviceId);
    await updateDoc(serviceRef, {
      expenses: updatedExpenses
    });
  };

  const handleAddTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !transactionDescription || !transactionValue) return;

    try {
      const transactionData = {
        description: transactionDescription.toUpperCase(),
        type: transactionType,
        value: transactionValue,
        date: new Date().toISOString().split('T')[0],
        createdAt: new Date().toISOString()
      };

      await addDoc(collection(db, 'tenants', (currentUser.tenantId || currentUser.uid), 'transactions'), transactionData);
      
      setTransactionDescription('');
      setTransactionValue(undefined);
      alert('LANÇAMENTO REALIZADO COM SUCESSO!');
    } catch (error) {
      console.error("Erro ao lançar transação:", error);
      alert('ERRO AO LANÇAR TRANSAÇÃO.');
    }
  };

  const handleDeleteTransaction = async (id: string) => {
    if (!currentUser || !window.confirm('DESEJA EXCLUIR ESTE LANÇAMENTO?')) return;
    try {
      await deleteDoc(doc(db, 'tenants', (currentUser.tenantId || currentUser.uid), 'transactions', id));
    } catch (error) {
      console.error("Erro ao excluir transação:", error);
    }
  };

  const handleResetCashier = async () => {
    if (!currentUser || !window.confirm('ATENÇÃO: DESEJA REALMENTE ZERAR O CAIXA? ISSO APAGARÁ TODOS OS LANÇAMENTOS (ENTRADAS E SAÍDAS) ATUAIS DEFINITIVAMENTE.')) return;
    
    try {
      setIsAuthLoading(true);
      const tenantId = currentUser.tenantId || currentUser.uid;
      const q = query(collection(db, 'tenants', tenantId, 'transactions'));
      const snapshot = await getDocs(q);
      
      if (snapshot.empty) {
        alert('O CAIXA JÁ ESTÁ VAZIO.');
        return;
      }

      // Deletar em lote (batch) para ser mais rápido e atômico
      const BATCH_SIZE = 500;
      const docs = snapshot.docs;
      
      for (let i = 0; i < docs.length; i += BATCH_SIZE) {
        const batch = docs.slice(i, i + BATCH_SIZE);
        const deletePromises = batch.map(d => deleteDoc(doc(db, 'tenants', tenantId, 'transactions', d.id)));
        await Promise.all(deletePromises);
      }
      
      alert('CAIXA ZERADO COM SUCESSO!');
    } catch (error) {
      console.error("Erro ao zerar caixa:", error);
      alert('ERRO AO ZERAR CAIXA.');
    } finally {
      setIsAuthLoading(false);
    }
  };

  const getBadgeColor = (status: ServiceStatus) => {
    switch (status) {
      case 'Pendente': return 'bg-zinc-800 text-zinc-400';
      case 'Em Produção': return 'bg-amber-500/20 text-amber-500';
      case 'Finalizado': return 'bg-white text-black';
      case 'Entregue': return 'bg-zinc-900 text-zinc-600';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center font-black animate-pulse uppercase tracking-[0.5em] text-xs">
        Carregando Sistema...
      </div>
    );
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-black text-white font-sans selection:bg-white selection:text-black flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-zinc-950 border border-white/10 p-12 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-white" />
          <div className="flex flex-col items-center mb-12">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-emerald-600 rounded-none flex items-center justify-center mb-6">
              <Wrench size={32} className="text-white" />
            </div>
            <h1 className="text-2xl font-black uppercase tracking-tighter italic bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent">PRODUÇÃO MODERNA</h1>
            <p className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-600 mt-2">Plataforma de Gestão SaaS</p>
          </div>

          <AnimatePresence mode="wait">
            {authMode === 'login' ? (
              <motion.form 
                key="login"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                onSubmit={isEmployeeLogin ? handleEmployeeLogin : handleLogin} 
                className="flex flex-col gap-4"
              >
                <div className="flex bg-zinc-900/50 p-1 rounded-none border border-white/5 mb-2">
                  <button 
                    type="button"
                    onClick={() => setIsEmployeeLogin(false)}
                    className={`flex-1 py-3 text-[9px] font-black uppercase tracking-widest transition-all ${!isEmployeeLogin ? 'bg-white text-black' : 'text-zinc-600'}`}
                  >
                    Admin / Empresa
                  </button>
                  <button 
                    type="button"
                    onClick={() => setIsEmployeeLogin(true)}
                    className={`flex-1 py-3 text-[9px] font-black uppercase tracking-widest transition-all ${isEmployeeLogin ? 'bg-white text-black' : 'text-zinc-600'}`}
                  >
                    Funcionário (CPF)
                  </button>
                </div>

                {isEmployeeLogin ? (
                  <div className="flex flex-col gap-4">
                    <div className="flex flex-col gap-1">
                      <label className="text-[8px] font-black text-zinc-600 uppercase tracking-widest italic">Acesso via seu CPF</label>
                      <input 
                        placeholder="DIGITE SEU CPF (SOMENTE NÚMEROS)" 
                        className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-800 text-sm focus:border-white outline-none"
                        value={employeeCPFLogin}
                        onChange={e => setEmployeeCPFLogin(e.target.value)}
                        required
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="text-[8px] font-black text-zinc-600 uppercase tracking-widest italic">Sua Senha</label>
                      <input 
                        type="password"
                        placeholder="••••••••" 
                        className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-800 text-sm focus:border-white outline-none"
                        value={loginPassword}
                        onChange={e => setLoginPassword(e.target.value)}
                        required
                      />
                    </div>
                    <button 
                      type="submit"
                      disabled={isAuthLoading}
                      className="bg-emerald-600 disabled:opacity-50 text-white py-4 font-black uppercase text-[10px] tracking-widest mt-4 hover:bg-emerald-500 transition-all font-display italic"
                    >
                      {isAuthLoading ? 'AUTENTICANDO...' : 'ACESSAR MEU PAINEL'}
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="flex flex-col gap-1">
                      <label className="text-[8px] font-black text-zinc-600 uppercase tracking-widest">Seu CPF</label>
                      <input 
                        placeholder="000.000.000-00" 
                        className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-800 text-sm focus:border-white outline-none"
                        value={loginCpf}
                        onChange={e => setLoginCpf(e.target.value)}
                        required
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="text-[8px] font-black text-zinc-600 uppercase tracking-widest">Sua Senha</label>
                      <div className="relative">
                        <input 
                          type={showPassword ? "text" : "password"}
                          placeholder="••••••••" 
                          className="w-full bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-800 text-sm focus:border-white outline-none pr-12"
                          value={loginPassword}
                          onChange={e => setLoginPassword(e.target.value)}
                          required
                        />
                        <button 
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-white transition-colors"
                        >
                          {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                        </button>
                      </div>
                    </div>
                    <button 
                      disabled={isAuthLoading}
                      className="bg-white text-black py-4 font-black uppercase text-[10px] tracking-widest mt-4 hover:invert transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isAuthLoading ? 'PROCESSANDO...' : 'ENTRAR NO SISTEMA'}
                    </button>
                  </>
                )}

                <a 
                  href="https://wa.me/5500000000000?text=Olá,%20preciso%20resetar%20minha%20senha%20no%20sistema%20Produção%20Moderna" 
                  target="_blank"
                  rel="noreferrer"
                  className="text-center text-[8px] font-black text-zinc-600 uppercase tracking-widest hover:text-white transition-colors mt-2"
                >
                  Esqueci minha senha / Suporte via WhatsApp
                </a>
                <div className="bg-zinc-900/50 p-4 border border-white/5 mt-4 text-center">
                  <p className="text-[8px] text-zinc-500 font-bold uppercase tracking-widest leading-relaxed">
                    Acesso pendente? Envie comprovante para o suporte.
                  </p>
                </div>
                <div className="text-center mt-6">
                  <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">Ainda não tem acesso?</span>
                  <button 
                    type="button" 
                    onClick={() => setAuthMode('register')} 
                    className="block w-full mt-2 text-[10px] text-white underline uppercase tracking-widest font-black"
                  >
                    Crie sua conta agora
                  </button>
                </div>
              </motion.form>
            ) : (
              <motion.form 
                key="register"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                onSubmit={handleRegister} 
                className="flex flex-col gap-4"
              >
                <input 
                  placeholder="NOME DA EMPRESA / TITULAR" 
                  className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-800 text-sm focus:border-white outline-none"
                  value={registerName}
                  onChange={e => setRegisterName(e.target.value)}
                  required
                />
                <input 
                  placeholder="Seu CPF (Somente números)" 
                  className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-800 text-sm focus:border-white outline-none"
                  value={registerCpf}
                  onChange={e => setRegisterCpf(e.target.value)}
                  required
                />
                <input 
                  placeholder="Telefone (WhatsApp)" 
                  className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-800 text-sm focus:border-white outline-none"
                  value={registerPhone}
                  onChange={e => setRegisterPhone(e.target.value)}
                  required
                />
                <div className="relative">
                  <input 
                    type={showPassword ? "text" : "password"}
                    placeholder="CRIAR SENHA" 
                    className="w-full bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-800 text-sm focus:border-white outline-none pr-12"
                    value={registerPassword}
                    onChange={e => setRegisterPassword(e.target.value)}
                    required
                  />
                  <button 
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-white transition-colors"
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                <div className="relative">
                  <input 
                    type={showPassword ? "text" : "password"}
                    placeholder="CONFIRMAR SENHA" 
                    className="w-full bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-800 text-sm focus:border-white outline-none pr-12"
                    value={registerConfirmPassword}
                    onChange={e => setRegisterConfirmPassword(e.target.value)}
                    required
                  />
                </div>
                
                <div className="bg-zinc-900 p-4 border border-white/5 mt-4">
                  <p className="text-[9px] text-zinc-400 font-bold uppercase tracking-widest leading-relaxed">
                    Pagamento de <span className="text-white">R$ 39,90</span> mensal.<br />
                    Pague e envie comprovante ao suporte.
                  </p>
                  <a 
                    href="https://mpago.la/14uuybf" 
                    target="_blank" 
                    rel="noreferrer"
                    className="flex items-center gap-2 text-white font-black uppercase text-[10px] tracking-widest mt-3 hover:underline"
                  >
                    Abrir Link de Pagamento <ExternalLink size={12} />
                  </a>
                </div>

                <button 
                  disabled={isAuthLoading}
                  className="bg-white text-black py-4 font-black uppercase text-[10px] tracking-widest mt-4 hover:invert transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isAuthLoading ? 'ENVIANDO...' : 'SOLICITAR ACESSO'}
                </button>
                <button type="button" onClick={() => setAuthMode('login')} className="mt-4 text-[10px] text-zinc-500 underline uppercase tracking-widest font-black">Já sou cliente</button>
              </motion.form>
            )}
          </AnimatePresence>
          
          <div className="mt-12 pt-8 border-t border-white/5 flex flex-col items-center gap-4">
            <a 
              href="https://wa.me/5562996346075" 
              className="flex items-center gap-2 text-zinc-600 font-black uppercase text-[9px] tracking-[0.2em] hover:text-white transition-colors"
            >
              <MessageSquare size={14} /> SUPORTE TÉCNICO (WHATSAPP)
            </a>
          </div>
        </div>
      </div>
    );
  }

  if (currentUser.status === 'pending' && !currentUser.isAdmin) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-zinc-950 border border-white/10 p-12 text-center">
          <Clock size={48} className="mx-auto mb-8 text-zinc-600" />
          <h2 className="text-3xl font-black uppercase italic mb-4">Aguardando Aprovação</h2>
          <p className="text-zinc-500 text-sm font-medium uppercase tracking-widest leading-loose mb-8">
            Seu cadastro foi recebido.<br />
            Para liberar seu acesso, envie o comprovante de pagamento para nosso suporte.
          </p>
          <div className="bg-white/5 p-6 border border-white/10 mb-8 text-center">
            <p className="text-[10px] font-black uppercase text-zinc-400 mb-2">Mensalidade: R$ 39,90</p>
            <a href="https://mpago.la/14uuybf" target="_blank" rel="noreferrer" className="text-xs font-black uppercase underline hover:text-emerald-400">Pagar agora</a>
            <p className="text-[8px] font-black uppercase text-zinc-500 mt-4 tracking-widest italic">Pague e envie comprovante ao suporte</p>
          </div>
          <a href="https://wa.me/5562996346075" className="bg-white text-black py-4 px-8 font-black uppercase text-[10px] tracking-widest block hover:invert transition-all">Enviar Comprovante (WhatsApp)</a>
          <button onClick={handleSignOut} className="mt-8 text-zinc-700 text-[10px] font-black uppercase underline">Sair da conta</button>
        </div>
      </div>
    );
  }

  if (currentUser.status === 'blocked') {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-zinc-950 border border-red-500/30 p-12 text-center">
          <ShieldAlert size={48} className="mx-auto mb-8 text-red-500" />
          <h2 className="text-3xl font-black uppercase italic mb-4">Acesso Bloqueado</h2>
          <p className="text-zinc-500 text-sm font-medium uppercase tracking-widest leading-loose mb-8">
            Sua assinatura expirou ou seu acesso foi suspenso.<br />
            Entre em contato com o suporte técnico.
          </p>
          <a href="https://wa.me/5562996346075" className="bg-white text-black py-4 px-8 font-black uppercase text-[10px] tracking-widest block hover:invert transition-all">Falar com Suporte</a>
          <button onClick={handleSignOut} className="mt-8 text-zinc-700 text-[10px] font-black uppercase underline">Sair da conta</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-white selection:text-black flex flex-col md:flex-row">
      <motion.nav 
        initial={{ x: -300, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        className="w-full md:w-64 border-b md:border-b-0 md:border-r border-white/10 p-8 flex flex-col gap-12 z-20 bg-black overflow-y-auto"
      >
        <button 
          onClick={handleHomeClick}
          className="flex items-center gap-3 hover:opacity-80 transition-opacity text-left"
        >
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-emerald-600 rounded-none flex items-center justify-center">
            <Wrench size={20} className="text-white" />
          </div>
          <h1 className="text-lg font-black uppercase tracking-tighter font-display italic bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent">PRODUÇÃO MODERNA</h1>
        </button>

        <div className="flex flex-col gap-2">
          {!currentUser.isAdmin && currentUser.role !== 'employee' && (
            <div className="mb-4">
              <a 
                href="https://mpago.la/14uuybf" 
                target="_blank" 
                rel="noreferrer"
                className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 font-black uppercase text-[8px] tracking-[0.2em] flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-900/20 border border-emerald-400/20"
              >
                <CreditCard size={12} /> Assinatura R$ 39,90
              </a>
              <p className="text-[7px] font-black uppercase text-zinc-600 mt-2 text-center tracking-wider italic">Pague e envie comprovante ao suporte</p>
            </div>
          )}
          {[
            ...(currentUser?.role === 'employee' 
              ? TABS.filter(t => t.id === 'producao' || t.id === 'meu-extrato') 
              : TABS.filter(t => t.id !== 'meu-extrato')),
            ...(currentUser?.isAdmin ? [{ id: 'master', label: 'MASTER', icon: Settings }] : [])
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-4 px-4 py-3 text-[10px] font-black uppercase tracking-widest transition-all rounded-none ${
                activeTab === tab.id 
                  ? 'bg-gradient-to-r from-blue-600 to-emerald-600 text-white shadow-lg shadow-blue-900/20' 
                  : 'text-zinc-500 hover:text-white hover:bg-white/5'
              }`}
            >
              {tab.icon && <tab.icon size={16} />}
              <span>{tab.id === 'producao' && currentUser?.role === 'employee' ? 'MINHA PRODUÇÃO' : tab.label}</span>
            </button>
          ))}
        </div>

        <div className="mt-auto border-t border-white/10 pt-8">
          <div className="text-[10px] font-black uppercase tracking-widest text-zinc-600 mb-2">Logado como</div>
          <div className="text-sm font-bold uppercase tracking-tight truncate mb-1 leading-tight">
            {currentUser.name || 'SISTEMA'}
          </div>
          <div className={`text-[7px] font-black uppercase tracking-widest px-2 py-0.5 rounded inline-block mb-4 ${
            currentUser.isAdmin ? 'bg-red-500/10 text-red-500' : 
            currentUser.role === 'employee' ? 'bg-blue-500/10 text-blue-500' : 'bg-emerald-500/10 text-emerald-500'
          }`}>
            {currentUser.isAdmin ? 'MASTER ADMIN' : currentUser.role === 'employee' ? 'FUNCIONÁRIO' : 'DONO / EMPRESA'}
          </div>
          <button 
            onClick={handleSignOut}
            className="flex items-center gap-2 text-zinc-600 hover:text-red-500 text-[10px] font-black uppercase tracking-widest transition-colors"
          >
            <LogOut size={14} /> Sair do Sistema
          </button>
        </div>
      </motion.nav>

      <main className="flex-1 p-4 md:p-12 min-h-screen md:h-screen overflow-y-auto pb-24 relative">
        <AnimatePresence mode="wait">
            <motion.div 
              key="active-content"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col h-full"
            >
              {activeTab === 'master' && currentUser.isAdmin ? (
                <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-12 md:mb-16">
                  <div className="max-w-xl">
                    <div className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-600 mb-4">Painel Administrador</div>
                    <h2 className="text-4xl md:text-7xl font-black font-display uppercase leading-tight md:leading-[0.85] tracking-tighter bg-gradient-to-r from-blue-500 to-emerald-500 bg-clip-text text-transparent">
                      CONTROLE DE<br />USUÁRIOS
                    </h2>
                  </div>
                  <div className="flex flex-col md:items-end gap-3 w-full md:w-auto">
                    <button 
                      onClick={() => setShowAdminNewUserModal(true)}
                      className="bg-emerald-600 text-white px-8 py-4 font-black uppercase text-[12px] tracking-widest flex items-center justify-center gap-2 hover:bg-emerald-500 transition-all shadow-xl shadow-emerald-900/40 w-full md:w-auto border-2 border-emerald-400/30"
                    >
                      <UserPlus size={16} /> NOVO CLIENTE (DONO)
                    </button>
                    <button 
                      onClick={() => setShowChangePasswordModal(true)}
                      className="bg-zinc-800 text-white px-8 py-3 font-black uppercase text-[10px] tracking-widest flex items-center justify-center gap-2 hover:bg-zinc-700 transition-all shadow-lg w-full md:w-auto border border-white/10"
                    >
                      <Lock size={14} /> ALTERAR MINHA SENHA
                    </button>
                    <button 
                      onClick={handleMigrateOldUsers}
                      disabled={isMigrating}
                      className="bg-zinc-800 text-emerald-500 px-8 py-3 font-black uppercase text-[10px] tracking-widest flex items-center justify-center gap-2 hover:bg-zinc-700 transition-all shadow-lg w-full md:w-auto border border-emerald-500/20 disabled:opacity-50"
                    >
                      <RefreshCw size={14} className={isMigrating ? "animate-spin" : ""} /> {isMigrating ? "MIGRANDO..." : "MIGRAR USUÁRIOS ANTIGOS"}
                    </button>
                  </div>
                </header>
              ) : (
                <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-12 md:mb-16">
                  <div className="max-w-xl">
                    <div className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-600 mb-4">Gestão de Fluxo</div>
                    <h2 className="text-4xl md:text-7xl font-black font-display uppercase leading-tight md:leading-[0.85] tracking-tighter">
                      <span className="bg-gradient-to-r from-blue-500 to-emerald-500 bg-clip-text text-transparent">GESTÃO DE<br />{TABS.find(t => t.id === activeTab)?.label || 'HISTÓRICO'}</span>
                    </h2>
                  </div>
                  
                  <div className="flex flex-col md:items-end gap-3 w-full md:w-auto">
                    {activeTab === 'funcionarios' ? (
                      <button 
                        onClick={() => setShowNewEmployeeModal(true)}
                        className="bg-gradient-to-r from-blue-600 to-emerald-600 text-white px-6 py-3 font-black uppercase text-[10px] tracking-widest flex items-center justify-center gap-2 hover:opacity-90 transition-all shadow-lg shadow-blue-900/20 w-full md:w-auto"
                      >
                        <UserPlus size={14} /> Novo Funcionário
                      </button>
                    ) : activeTab === 'producao' ? (
                      <button 
                        onClick={() => setShowNewServiceModal(true)}
                        className="bg-gradient-to-r from-blue-600 to-emerald-600 text-white px-6 py-3 font-black uppercase text-[10px] tracking-widest flex items-center justify-center gap-2 hover:opacity-90 transition-all shadow-lg shadow-blue-900/20 w-full md:w-auto"
                      >
                        <PlusCircle size={14} /> Novo Serviço
                      </button>
                    ) : (activeTab === 'master' && currentUser.isAdmin) ? (
                      <button 
                        onClick={() => setShowAdminNewUserModal(true)}
                        className="bg-gradient-to-r from-blue-600 to-emerald-600 text-white px-6 py-3 font-black uppercase text-[10px] tracking-widest flex items-center justify-center gap-2 hover:opacity-90 transition-all shadow-lg shadow-blue-900/20 w-full md:w-auto"
                      >
                        <UserPlus size={14} /> Novo Cliente (Dono)
                      </button>
                    ) : null}
                  </div>
                </header>
              )}

              <AnimatePresence mode="wait">
                {activeTab === 'producao' && (
                  <motion.div key="producao" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col gap-8">
                    {/* Resumo Rápido */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="bg-zinc-950 border border-white/5 p-4">
                        <span className="text-[7px] font-black text-zinc-600 uppercase tracking-widest block mb-1">Serviços Ativos</span>
                        <span className="text-xl font-black italic">{services.filter(s => s.status === 'Pendente' || s.status === 'Em Produção').length}</span>
                      </div>
                      <div className="bg-zinc-950 border border-white/5 p-4">
                        <span className="text-[7px] font-black text-zinc-600 uppercase tracking-widest block mb-1">Valor em Produção</span>
                        <span className="text-xl font-black italic text-blue-500">R$ {formatCurrency(
                          services
                            .filter(s => s.status === 'Pendente' || s.status === 'Em Produção')
                            .reduce((acc, curr) => acc + (curr.totalValue || 0), 0)
                        )}</span>
                      </div>
                      <div className="bg-zinc-950 border border-white/5 p-4">
                        <span className="text-[7px] font-black text-zinc-600 uppercase tracking-widest block mb-1">Entradas (Depósitos)</span>
                        <span className="text-xl font-black italic text-emerald-500">R$ {formatCurrency(
                          services
                            .filter(s => s.status === 'Pendente' || s.status === 'Em Produção')
                            .reduce((acc, curr) => acc + (curr.downPayment || 0), 0)
                        )}</span>
                      </div>
                      <div className="bg-zinc-950 border border-white/5 p-4">
                        <span className="text-[7px] font-black text-zinc-600 uppercase tracking-widest block mb-1">Comissões Pendentes</span>
                        <span className="text-xl font-black italic text-amber-500">R$ {formatCurrency(
                          services
                            .filter(s => s.status === 'Pendente' || s.status === 'Em Produção')
                            .reduce((acc, curr) => acc + (curr.commissionValue || 0), 0)
                        )}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {services.filter(s => s.status === 'Pendente' || s.status === 'Em Produção').map(service => (
                      <div key={service.id} className="bg-zinc-950 border border-white/10 flex flex-col group relative overflow-hidden transition-all hover:border-white/20">
                        <div className={`h-1 w-full ${getBadgeColor(service.status)}`} />
                        <div className="p-8">
                          <div className="flex justify-between items-start mb-6">
                            <span className={`text-[8px] font-black uppercase tracking-[0.2em] px-2 py-1 ${getBadgeColor(service.status)}`}>{service.status}</span>
                            <div className="flex gap-2">
                              <button onClick={() => setEditingService(service)} className="text-zinc-600 hover:text-white transition-colors"><Settings size={14} /></button>
                              <button onClick={() => handleDeleteService(service.id)} className="text-zinc-600 hover:text-red-500 transition-colors"><Trash2 size={14} /></button>
                            </div>
                          </div>
                          <h3 className="text-2xl font-black uppercase tracking-tighter italic mb-2 group-hover:text-blue-400 transition-colors">{service.clientName}</h3>
                          <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest mb-6 border-l-2 border-white/10 pl-4 h-12 overflow-hidden">{service.description}</p>
                          <div className="grid grid-cols-2 gap-4 mb-4">
                            <div className="bg-white/5 p-4">
                              <span className="text-[7px] font-black text-zinc-600 uppercase tracking-widest block mb-1">Total Geral</span>
                              <span className="text-sm font-black italic">R$ {formatCurrency(service.totalValue)}</span>
                            </div>
                            <div className="bg-white/5 p-4">
                              <span className="text-[7px] font-black text-zinc-600 uppercase tracking-widest block mb-1">Comissão</span>
                              <span className="text-sm font-black italic text-amber-500">R$ {formatCurrency(service.commissionValue)}</span>
                            </div>
                          </div>

                          <div className="bg-blue-500/10 border border-blue-500/20 p-4 mb-8">
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-[7px] font-black text-blue-400 uppercase tracking-widest block">Lucro Líquido Real</span>
                              <span className="text-[10px] font-black italic text-blue-400">
                                R$ {formatCurrency(service.totalValue - service.commissionValue - (service.expenses?.reduce((acc, curr) => acc + curr.value, 0) || 0))}
                              </span>
                            </div>
                            <div className="h-0.5 bg-blue-500/20 w-full mb-3" />
                            
                            {/* Lista de Despesas */}
                            <div className="flex flex-col gap-2 max-h-32 overflow-y-auto mb-4 scrollbar-hide">
                              {service.expenses && service.expenses.length > 0 ? (
                                service.expenses.map((exp, idx) => (
                                  <div key={idx} className="flex justify-between items-center bg-black/40 p-2 border border-white/5 group/exp">
                                    <div className="flex flex-col">
                                      <span className="text-[7px] font-bold text-zinc-400 uppercase">{exp.description}</span>
                                      <span className="text-[9px] font-black text-red-400">- R$ {formatCurrency(exp.value)}</span>
                                    </div>
                                    <button onClick={() => handleRemoveExpense(service.id, idx)} className="text-zinc-600 hover:text-red-500 opacity-0 group-hover/exp:opacity-100 transition-all">
                                      <X size={10} />
                                    </button>
                                  </div>
                                ))
                              ) : (
                                <span className="text-[6px] text-zinc-700 uppercase font-bold text-center py-2 italic">Nenhuma despesa lançada</span>
                              )}
                            </div>

                            {/* Botão de Adicionar Despesa */}
                            {addingExpenseServiceId === service.id ? (
                              <div className="flex flex-col gap-2 bg-zinc-900 p-2 border border-blue-500/30">
                                <input 
                                  type="text" 
                                  placeholder="DESCRIÇÃO" 
                                  value={expenseDescription}
                                  onChange={(e) => setExpenseDescription(e.target.value.toUpperCase())}
                                  className="bg-black border border-white/10 text-[8px] p-2 text-white font-bold tracking-widest placeholder:text-zinc-700 focus:outline-none focus:border-blue-500"
                                />
                                <div className="flex gap-2">
                                  <input 
                                    type="number" 
                                    placeholder="VALOR" 
                                    value={expenseValue || ''}
                                    onChange={(e) => setExpenseValue(Number(e.target.value))}
                                    className="bg-black border border-white/10 text-[8px] p-2 text-white font-bold tracking-widest placeholder:text-zinc-700 focus:outline-none focus:border-blue-500 flex-1"
                                  />
                                  <button onClick={() => handleAddExpense(service.id)} className="bg-blue-600 text-white px-3 text-[8px] font-black uppercase hover:bg-blue-500">LANÇAR</button>
                                  <button onClick={() => setAddingExpenseServiceId(null)} className="bg-zinc-800 text-zinc-500 px-2 hover:bg-zinc-700"><X size={12} /></button>
                                </div>
                              </div>
                            ) : (
                              <button 
                                onClick={() => setAddingExpenseServiceId(service.id)}
                                className="w-full py-2 border border-dashed border-blue-500/30 text-blue-500/50 hover:text-blue-400 hover:border-blue-500/50 transition-all text-[7px] font-black uppercase tracking-[0.2em]"
                              >
                                + LANÇAR DESPESA
                              </button>
                            )}
                          </div>
                          <div className="flex flex-col gap-3">
                            <button onClick={() => setAssigningServiceId(service.id)} className="flex items-center justify-between px-4 py-3 bg-zinc-900 border border-white/5 hover:bg-zinc-800 transition-all group/btn">
                              <span className="text-[8px] font-black uppercase tracking-widest text-zinc-400">Responsável:</span>
                              <span className="text-xs font-black uppercase italic group-hover/btn:text-white">
                                {employees.find(e => e.id === service.responsibleId)?.name || 'NÃO ATRIBUÍDO'}
                              </span>
                            </button>
                            <div className="flex gap-2">
                              <button onClick={() => updateStatus(service.id, 'Em Produção')} className={`flex-1 py-3 text-[8px] font-black uppercase tracking-widest transition-all ${service.status === 'Em Produção' ? 'bg-amber-500 text-black' : 'bg-white/5 hover:bg-white/10'}`}>PRODUZINDO</button>
                              <button onClick={() => updateStatus(service.id, 'Finalizado')} className="flex-1 py-3 bg-white text-black text-[8px] font-black uppercase tracking-widest hover:invert">FINALIZAR</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                    </div>
                    {services.filter(s => s.status === 'Pendente' || s.status === 'Em Produção').length === 0 && (
                      <div className="col-span-full py-20 border-2 border-dashed border-white/5 text-center">
                        <Wrench size={32} className="mx-auto mb-4 text-zinc-800" />
                        <p className="text-zinc-600 font-black uppercase text-[10px] tracking-widest italic">Nenhum serviço em produção no momento.</p>
                      </div>
                    )}
                  </motion.div>
                )}

                {activeTab === 'funcionarios' && (
                  <motion.div key="funcionarios" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col gap-4">
                    {employees.map(emp => (
                      <div key={emp.id} className="bg-zinc-950 border border-white/10 p-4 sm:p-8 flex flex-col md:flex-row justify-between items-center gap-6 group hover:border-white/20 transition-all">
                        <div className="flex items-center gap-6 w-full md:w-auto">
                          <div className="w-12 h-12 sm:w-16 sm:h-16 bg-white/5 flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all">
                            <User size={24} />
                          </div>
                          <div>
                            <div className="flex items-center gap-3 mb-1">
                              <h3 className="text-xl sm:text-2xl font-black uppercase tracking-tighter italic break-words">{emp.name}</h3>
                              <button onClick={() => setEditingEmployee(emp)} className="text-zinc-700 hover:text-white"><Settings size={12} /></button>
                              <button onClick={() => handleDeleteEmployee(emp.id)} className="text-zinc-700 hover:text-red-500"><Trash2 size={12} /></button>
                            </div>
                            <div className="flex items-center gap-4">
                              <span className="text-[8px] sm:text-[10px] font-black text-zinc-500 uppercase tracking-widest">Saldo Disponível</span>
                              <span className={`text-base sm:text-xl font-black italic ${emp.balance >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>R$ {formatCurrency(emp.balance)}</span>
                            </div>
                            {(emp.cpf || emp.password) && (
                              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2">
                                {emp.cpf && (
                                  <div className="flex items-center gap-2">
                                    <span className="text-[7px] font-bold text-zinc-600 uppercase">CPF:</span>
                                    <span className="text-[9px] font-black text-white tracking-widest">{emp.cpf}</span>
                                  </div>
                                )}
                                {emp.password && (
                                  <div className="flex items-center gap-2">
                                    <span className="text-[7px] font-bold text-zinc-600 uppercase">SENHA:</span>
                                    <span className="text-[9px] font-black text-emerald-400 tracking-widest">{emp.password}</span>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="flex gap-2 w-full md:w-auto">
                          <button onClick={() => setViewingStatementEmployeeId(emp.id)} className="flex-1 md:flex-none px-4 sm:px-6 py-3 border border-white/10 text-[8px] sm:text-[10px] font-black uppercase tracking-widest hover:bg-white hover:text-black transition-all">EXTRATO</button>
                          <button onClick={() => setLaunchingValeEmployeeId(emp.id)} className="flex-1 md:flex-none px-4 sm:px-6 py-3 bg-red-600 text-white text-[8px] sm:text-[10px] font-black uppercase tracking-widest hover:bg-red-500 transition-all">LANÇAR VALE</button>
                        </div>
                      </div>
                    ))}
                    {employees.length === 0 && (
                      <div className="py-20 border-2 border-dashed border-white/5 text-center">
                        <Users size={32} className="mx-auto mb-4 text-zinc-800" />
                        <p className="text-zinc-600 font-black uppercase text-[10px] tracking-widest italic">Nenhum funcionário cadastrado.</p>
                      </div>
                    )}
                  </motion.div>
                )}

                {activeTab === 'faturamento' && (() => {
                  const query = faturamentoSearch.toLowerCase();
                  
                  // Helper to parse dates
                  const parseDate = (dStr: string | undefined) => {
                    if (!dStr) return '';
                    if (dStr.includes('/')) {
                      const [d, m, y] = dStr.split('/');
                      return `${y}-${m}-${d}`;
                    }
                    return dStr;
                  };

                  // Filter services based on filters
                  const filteredServicesLocal = services.filter(s => {
                    const matchesSearch = s.clientName.toLowerCase().includes(query) || (s.cpf && s.cpf.includes(query));
                    const serviceDate = parseDate(s.deliveryDate || s.createdAt);
                    const matchesStart = faturamentoStartDate ? serviceDate >= faturamentoStartDate : true;
                    const matchesEnd = faturamentoEndDate ? serviceDate <= faturamentoEndDate : true;
                    return matchesSearch && matchesStart && matchesEnd;
                  });

                  // Filter transactions based on date filters
                  const filteredTransactionsLocal = transactions.filter(t => {
                    const tDate = t.date; // YYYY-MM-DD
                    const matchesStart = faturamentoStartDate ? tDate >= faturamentoStartDate : true;
                    const matchesEnd = faturamentoEndDate ? tDate <= faturamentoEndDate : true;
                    return matchesStart && matchesEnd;
                  });

                  // Calculate Totals using filtered data to avoid double counting
                  // Faturamento Bruto: Valor Total dos Serviços + Entradas Extras (que não são vinculadas a serviços)
                  const totalBilling = filteredServicesLocal.reduce((acc, curr) => acc + (curr.totalValue || 0), 0);
                  
                  // Entradas Extras: Apenas o que NÃO tem serviceId e NÃO é SINAL/ENTRADA de serviço (para limpar dados legados tbm)
                  const extraIncome = filteredTransactionsLocal.filter(t => {
                    if (t.type !== 'entrada') return false;
                    if (t.serviceId) return false;
                    const desc = (t.description || '').toUpperCase();
                    if (desc.includes('SINAL:') || desc.includes('ENTRADA ADICIONAL:') || desc.includes('RESTANTE SERV:')) return false;
                    return true;
                  }).reduce((acc, curr) => acc + curr.value, 0);
                  
                  const totalRevenue = totalBilling + extraIncome;
                  const totalExtraIncome = extraIncome;
                  
                  // Gastos: Comissões + Despesas de Serviços + Saídas Extras
                  const totalCommissionsAccrued = filteredServicesLocal.reduce((acc, curr) => acc + (curr.commissionValue || 0), 0);
                  const totalServiceExpensesAccrued = filteredServicesLocal.reduce((acc, curr) => acc + (curr.expenses?.reduce((sum, e) => sum + e.value, 0) || 0), 0);
                  
                  // Saídas Extras: O que não tem serviceId e não tem employeeId (vales e comissões já são tratados)
                  const extraExpenses = filteredTransactionsLocal.filter(t => {
                    if (t.type !== 'saida') return false;
                    if (t.serviceId) return false;
                    if (t.employeeId) return false;
                    const desc = (t.description || '').toUpperCase();
                    if (desc.includes('PAGTO COMISSÃO:') || desc.includes('VALE/ADIANT:')) return false;
                    return true;
                  }).reduce((acc, curr) => acc + curr.value, 0);

                  const totalExpenses = totalCommissionsAccrued + totalServiceExpensesAccrued + extraExpenses;

                  const totalNetProfit = totalRevenue - totalExpenses;

                  return (
                    <motion.div key="faturamento" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col gap-6 md:gap-10">
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 md:gap-8">
                        <div className="bg-zinc-950 border border-white/10 p-6">
                          <span className="text-[8px] font-black text-zinc-600 uppercase tracking-widest block mb-1">Vendas Totais</span>
                          <span className="text-xl md:text-3xl font-black italic text-emerald-500">R$ {formatCurrency(totalRevenue)}</span>
                        </div>
                        <div className="bg-zinc-950 border border-white/10 p-6">
                          <span className="text-[8px] font-black text-zinc-600 uppercase tracking-widest block mb-1">Extra (Entradas)</span>
                          <span className="text-xl md:text-2xl font-black italic text-sky-500">R$ {formatCurrency(totalExtraIncome)}</span>
                        </div>
                        <div className="bg-zinc-950 border border-white/10 p-6">
                          <span className="text-[8px] font-black text-zinc-600 uppercase tracking-widest block mb-1">Gastos Operacionais</span>
                          <span className="text-xl md:text-2xl font-black italic text-red-500">R$ {formatCurrency(totalExpenses)}</span>
                        </div>
                        <div className="bg-zinc-950 border border-white/10 p-6">
                          <span className="text-[8px] font-black text-zinc-600 uppercase tracking-widest block mb-1">Lucro Líquido Real</span>
                          <span className="text-xl md:text-3xl font-black italic text-white underline decoration-blue-500 underline-offset-8">R$ {formatCurrency(totalNetProfit)}</span>
                        </div>
                      </div>

                      <div className="bg-zinc-950 border border-white/5 p-4 md:p-8 flex flex-col md:flex-row gap-4 md:gap-8 items-end">
                        <div className="flex flex-col gap-2 w-full md:flex-1">
                          <label className="text-[8px] font-black text-zinc-600 uppercase tracking-widest italic">Buscar Cliente (Nome ou CPF)</label>
                          <input 
                            type="text" 
                            placeholder="EX: JOÃO SILVA OU 000.000.000-00"
                            className="bg-zinc-900 border border-white/10 px-4 py-3 text-[10px] md:text-xs font-bold text-white outline-none focus:border-white uppercase placeholder:text-zinc-700" 
                            value={faturamentoSearch} 
                            onChange={e => setFaturamentoSearch(e.target.value)} 
                          />
                        </div>
                        <div className="flex flex-col gap-2 w-full md:w-auto">
                          <label className="text-[8px] font-black text-zinc-600 uppercase tracking-widest italic">Filtrar por Período</label>
                          <div className="grid grid-cols-2 gap-2">
                            <input type="date" className="bg-zinc-900 border border-white/10 px-4 py-3 text-[10px] font-bold text-white outline-none focus:border-white" value={faturamentoStartDate} onChange={e => setFaturamentoStartDate(e.target.value)} />
                            <input type="date" className="bg-zinc-900 border border-white/10 px-4 py-3 text-[10px] font-bold text-white outline-none focus:border-white" value={faturamentoEndDate} onChange={e => setFaturamentoEndDate(e.target.value)} />
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col border border-white/10 overflow-hidden">
                        <div className="hidden md:grid grid-cols-7 bg-white text-black p-4 text-[8px] font-black uppercase tracking-widest italic">
                          <div className="col-span-2">Cliente / CPF</div>
                          <div className="text-center">Data</div>
                          <div className="text-center">Vlr. Serviço</div>
                          <div className="text-center">Comissão</div>
                          <div className="text-center">Despesas</div>
                          <div className="text-right">Lucro Líquido</div>
                        </div>
                        {filteredServicesLocal.map(service => {
                            const totalExpenses = service.expenses?.reduce((acc, curr) => acc + curr.value, 0) || 0;
                            const netProfit = (service.totalValue || 0) - (service.commissionValue || 0) - totalExpenses;
                            
                            return (
                              <div key={service.id} className="flex flex-col md:grid md:grid-cols-7 p-6 border-b border-white/5 hover:bg-white/5 items-center transition-colors gap-4 md:gap-0">
                                <div className="col-span-2 w-full md:w-auto">
                                  <div className="text-xs md:text-sm font-black uppercase italic mb-1">{service.clientName}</div>
                                  <div className="text-[8px] font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-2">
                                    {service.cpf || 'SEM CPF'}
                                    <span className={`text-[7px] px-1 py-0.5 ${getBadgeColor(service.status)}`}>{service.status}</span>
                                  </div>
                                </div>
                                <div className="text-center text-[10px] font-bold text-zinc-400 uppercase w-full md:w-auto">{service.deliveryDate || service.createdAt}</div>
                                <div className="text-center text-[10px] md:text-xs font-black italic w-full md:w-auto">
                                  <span className="md:hidden text-zinc-600 block mb-1">TOTAL:</span>
                                  R$ {formatCurrency(service.totalValue)}
                                </div>
                                <div className="text-center text-[10px] md:text-xs font-black italic text-amber-500 w-full md:w-auto">
                                  <span className="md:hidden text-zinc-600 block mb-1">COMISSÃO:</span>
                                  R$ {formatCurrency(service.commissionValue)}
                                </div>
                                <div className="text-center text-[10px] md:text-xs font-black italic text-red-500 w-full md:w-auto">
                                  <span className="md:hidden text-zinc-600 block mb-1">DESPESAS:</span>
                                  R$ {formatCurrency(totalExpenses)}
                                </div>
                                <div className={`text-right text-[10px] md:text-xs font-black italic w-full md:w-auto ${netProfit >= 0 ? 'text-blue-400' : 'text-red-500'}`}>
                                  <span className="md:hidden text-zinc-600 block mb-1">LUCRO:</span>
                                  R$ {formatCurrency(netProfit)}
                                </div>
                              </div>
                            );
                          })}
                        {filteredServicesLocal.length === 0 && (
                          <div className="py-20 text-center border-b border-white/5">
                            <p className="text-zinc-600 font-black uppercase text-[10px] tracking-widest italic">Nenhum faturamento registrado no período.</p>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  );
                })()}

                {activeTab === 'caixa' && (
                  <motion.div key="caixa-content" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col gap-8 pb-32">
                    {/* Resumo do Caixa */}
                    <div className="flex justify-between items-center mb-2">
                       <h2 className="text-xl font-black italic tracking-tighter text-white">GESTÃO DE FLUXO DE CAIXA</h2>
                       <button 
                         onClick={handleResetCashier}
                         className="flex items-center gap-2 bg-red-600/10 text-red-500 border border-red-600/20 px-4 py-2 text-[8px] font-black uppercase tracking-widest hover:bg-red-600 hover:text-white transition-all shadow-lg"
                       >
                         <Trash2 size={12} />
                         Zerar Caixa Total
                       </button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="bg-zinc-950 border border-white/5 p-6 shadow-2xl">
                        <span className="text-[7px] font-black text-zinc-600 uppercase tracking-widest block mb-1">Entradas Avulsas</span>
                        <span className="text-xl font-black italic text-emerald-500">R$ {formatCurrency(transactions?.filter(t => t.type === 'entrada').reduce((acc, curr) => acc + (curr.value || 0), 0) || 0)}</span>
                      </div>
                      <div className="bg-zinc-950 border border-white/5 p-6 shadow-2xl">
                        <span className="text-[7px] font-black text-zinc-600 uppercase tracking-widest block mb-1">Saídas Avulsas</span>
                        <span className="text-xl font-black italic text-red-500">R$ {formatCurrency(transactions?.filter(t => t.type === 'saida').reduce((acc, curr) => acc + (curr.value || 0), 0) || 0)}</span>
                      </div>
                      <div className="bg-zinc-950 border border-white/5 p-6 shadow-2xl border-b-blue-500">
                        <span className="text-[7px] font-black text-zinc-600 uppercase tracking-widest block mb-1">Saldo Atual</span>
                        <span className="text-xl font-black italic text-white underline decoration-blue-500 decoration-2 underline-offset-8">
                          R$ {formatCurrency(
                            (transactions?.filter(t => t.type === 'entrada').reduce((acc, curr) => acc + (curr.value || 0), 0) || 0) -
                            (transactions?.filter(t => t.type === 'saida').reduce((acc, curr) => acc + (curr.value || 0), 0) || 0)
                          )}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                      {/* Formulário de Lançamento */}
                      <div className="bg-zinc-950 border border-white/10 p-8 h-fit shadow-2xl relative overflow-hidden group">
                        <div className="absolute top-0 left-0 w-1 h-full bg-blue-600 group-hover:h-0 transition-all duration-500" />
                        <h3 className="text-sm font-black italic uppercase mb-8 flex items-center gap-3">
                          <PlusCircle size={18} className="text-blue-500" />
                          <span className="tracking-tighter">Novo Lançamento</span>
                        </h3>
                        <form onSubmit={handleAddTransaction} className="flex flex-col gap-6">
                          <div className="flex flex-col gap-2">
                            <label className="text-[8px] font-black text-zinc-600 uppercase tracking-[0.2em]">Tipo de Operação</label>
                            <select 
                              value={transactionType}
                              onChange={(e) => setTransactionType(e.target.value as 'entrada' | 'saida')}
                              className="bg-black border border-white/10 p-4 text-[10px] font-black text-white outline-none focus:border-blue-500 uppercase h-[50px] appearance-none cursor-pointer"
                            >
                              <option value="saida">SAÍDA (Gasto/Despesa)</option>
                              <option value="entrada">ENTRADA (Aporte/Extra)</option>
                            </select>
                          </div>
                          <div className="flex flex-col gap-2">
                            <label className="text-[8px] font-black text-zinc-600 uppercase tracking-[0.2em]">Descrição Detalhada</label>
                            <input 
                              type="text" 
                              placeholder="ONDE O DINHEIRO FOI/VEIO?"
                              value={transactionDescription}
                              onChange={(e) => setTransactionDescription(e.target.value.toUpperCase())}
                              className="bg-black border border-white/10 p-4 text-[10px] font-black text-white outline-none focus:border-blue-500 uppercase h-[50px] placeholder:text-zinc-800"
                              required
                            />
                          </div>
                          <div className="flex flex-col gap-2">
                            <label className="text-[8px] font-black text-zinc-600 uppercase tracking-[0.2em]">Valor Financeiro (R$)</label>
                            <input 
                              type="number" 
                              placeholder="0,00"
                              value={transactionValue || ''}
                              onChange={(e) => setTransactionValue(Number(e.target.value))}
                              className="bg-black border border-white/10 p-4 text-[10px] font-black text-white outline-none focus:border-blue-500 uppercase h-[50px] placeholder:text-zinc-800"
                              required
                            />
                          </div>
                          <button type="submit" className="mt-4 bg-white text-black py-5 text-[10px] font-black uppercase tracking-[0.3em] hover:bg-blue-600 hover:text-white transition-all shadow-xl active:scale-95">
                            CONFIRMAR LANÇAMENTO
                          </button>
                        </form>
                      </div>

                      {/* Lista de Movimentações */}
                      <div className="lg:col-span-2 flex flex-col bg-zinc-950 border border-white/10 shadow-2xl">
                        <div className="grid grid-cols-4 bg-zinc-900 p-6 text-[8px] font-black uppercase tracking-[0.3em] text-zinc-500 border-b border-white/10">
                          <div>Data</div>
                          <div className="col-span-2">Descrição / Tipo</div>
                          <div className="text-right">Valor</div>
                        </div>
                        <div className="max-h-[600px] overflow-y-auto scrollbar-hide">
                          {transactions && transactions.length > 0 ? (
                            transactions.map(t => (
                              <div key={t.id} className="grid grid-cols-1 md:grid-cols-4 p-8 border-b border-white/5 hover:bg-white/[0.02] items-center group transition-all gap-4 md:gap-0">
                                <div className="text-[10px] font-black font-mono text-zinc-600">
                                  {t.createdAt ? new Date(t.createdAt).toLocaleDateString('pt-BR') : t.date || '---'}
                                </div>
                                <div className="col-span-2 flex items-center gap-4">
                                  <span className={`inline-block px-2 py-1 text-[7px] font-black uppercase tracking-widest rounded-sm ${t.type === 'entrada' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'}`}>
                                    {t.type}
                                  </span>
                                  <span className="text-[11px] font-black uppercase italic text-zinc-300 tracking-tight">{t.description}</span>
                                </div>
                                <div className="flex items-center justify-between md:justify-end gap-6">
                                  <span className={`text-sm font-black italic ${t.type === 'entrada' ? 'text-emerald-500' : 'text-red-500'}`}>
                                    {t.type === 'entrada' ? '+' : '-'} R$ {formatCurrency(t.value)}
                                  </span>
                                  <button onClick={() => handleDeleteTransaction(t.id)} className="w-10 h-10 flex items-center justify-center border border-white/5 text-zinc-800 hover:text-red-500 hover:border-red-500/20 md:opacity-0 md:group-hover:opacity-100 transition-all rounded-full">
                                    <Trash2 size={14} />
                                  </button>
                                </div>
                              </div>
                            ))
                          ) : (
                            <div className="py-32 text-center">
                              <TrendingDown size={48} className="mx-auto mb-6 text-zinc-900" />
                              <p className="text-zinc-700 font-black uppercase text-[10px] tracking-[0.4em] italic leading-relaxed">
                                Fluxo de caixa vazio.<br />Aguardando primeiros lançamentos.
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'administracao' && (
                  <motion.div key="administracao-content" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col gap-10 pb-32">
                    <div className="bg-zinc-950 border border-white/5 p-6 md:p-10 flex flex-col md:flex-row gap-8 items-end shadow-2xl">
                      <div className="flex flex-col gap-3 flex-1 w-full">
                        <label className="text-[9px] font-black text-zinc-600 uppercase tracking-widest italic">Período de Análise</label>
                        <div className="grid grid-cols-2 gap-4">
                          <input type="date" className="bg-black border border-white/10 px-5 py-4 text-[10px] font-black text-white outline-none focus:border-blue-500 hover:bg-white/[0.02] transition-all" value={filterStartDate} onChange={e => setFilterStartDate(e.target.value)} />
                          <input type="date" className="bg-black border border-white/10 px-5 py-4 text-[10px] font-black text-white outline-none focus:border-blue-500 hover:bg-white/[0.02] transition-all" value={filterEndDate} onChange={e => setFilterEndDate(e.target.value)} />
                        </div>
                      </div>
                      <div className="flex flex-col gap-3 flex-1 w-full">
                        <label className="text-[9px] font-black text-zinc-600 uppercase tracking-widest italic">Colaborador</label>
                        <select className="bg-black border border-white/10 px-5 py-4 text-[10px] font-black text-white outline-none focus:border-blue-500 appearance-none h-[54px] uppercase cursor-pointer hover:bg-white/[0.02] transition-all" value={filterEmployeeId} onChange={e => setFilterEmployeeId(e.target.value)}>
                          <option value="all">TODOS OS COLABORADORES</option>
                          {employees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                        </select>
                      </div>
                    </div>

                    <div className="bg-zinc-950 border border-white/10 shadow-2xl">
                      <div className="hidden md:grid grid-cols-7 bg-zinc-900 p-6 text-[8px] font-black uppercase tracking-[0.4em] text-zinc-500 italic border-b border-white/10">
                        <div className="col-span-2">Identificação / Serv.</div>
                        <div className="text-center">V. Total</div>
                        <div className="text-center">Sinal (Entrada)</div>
                        <div className="text-center">Comissão</div>
                        <div className="text-right col-span-2">Ação / Status</div>
                      </div>
                      <div className="flex flex-col">
                        {services
                          .filter(s => filterEmployeeId === 'all' || s.responsibleId === filterEmployeeId)
                          .filter(s => {
                            const parseDate = (dStr: string | undefined) => {
                              if (!dStr) return '';
                              if (dStr.includes('/')) {
                                const [d, m, y] = dStr.split('/');
                                return `${y}-${m}-${d}`;
                              }
                              return dStr;
                            };
                            const serviceDate = parseDate(s.deliveryDate || s.createdAt);
                            const matchesStart = filterStartDate ? serviceDate >= filterStartDate : true;
                            const matchesEnd = filterEndDate ? serviceDate <= filterEndDate : true;
                            return matchesStart && matchesEnd;
                          })
                          .map(service => (
                          <div key={service.id} className="flex flex-col md:grid md:grid-cols-7 p-8 border-b border-white/5 hover:bg-white/[0.02] items-center transition-all gap-8 md:gap-0">
                            <div className="col-span-2 w-full md:w-auto border-l-2 border-white/10 pl-6 h-full flex flex-col justify-center">
                              <div className="flex items-center gap-3 mb-2">
                                <div className="text-sm font-black uppercase italic tracking-tighter text-white">{service.clientName}</div>
                                <span className={`text-[7px] px-2 py-1 ${getBadgeColor(service.status)} font-black uppercase tracking-widest`}>{service.status}</span>
                              </div>
                              <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-tight truncate max-w-[280px] mb-2">{service.description}</div>
                              <div className="text-[8px] text-zinc-700 font-mono font-bold">{service.deliveryDate || `CRIADO: ${service.createdAt}`}</div>
                            </div>
                            
                            <div className="text-center w-full md:w-auto bg-white/5 py-4 md:bg-transparent md:py-0">
                              <span className="md:hidden text-[7px] font-black text-zinc-600 block mb-2 uppercase tracking-widest">Valor do Serviço</span>
                              <span className="text-xs font-black italic">R$ {formatCurrency(service.totalValue)}</span>
                            </div>

                            <div className="text-center w-full md:w-auto bg-blue-500/5 py-4 md:bg-transparent md:py-0 border-y border-white/5 md:border-0">
                              <span className="md:hidden text-[7px] font-black text-blue-500/50 block mb-2 uppercase tracking-widest">Sinal (Entrada)</span>
                              <span className="text-xs font-black italic text-blue-400">R$ {formatCurrency(service.downPayment || 0)}</span>
                            </div>

                            <div className="text-center flex flex-col items-center w-full md:w-auto bg-emerald-500/5 py-4 md:bg-transparent md:py-0">
                              <span className="md:hidden text-[7px] font-black text-emerald-500/50 block mb-2 uppercase tracking-widest">Comissão</span>
                              <span className="text-sm font-black italic text-emerald-500">R$ {formatCurrency(service.commissionValue)}</span>
                              <div className="mt-2">
                                {service.commissionStatus === 'paid' ? (
                                  <span className="text-[8px] font-black text-emerald-500/40 uppercase tracking-[0.2em] px-2 py-1 border border-emerald-500/10">CONCLUÍDO</span>
                                ) : (
                                  <button onClick={() => handleMarkAsPaid(service.id)} className="text-[8px] font-black text-amber-500 border border-amber-500/30 px-3 py-1 hover:bg-amber-500 hover:text-black transition-all uppercase tracking-widest">PAGAR</button>
                                )}
                              </div>
                            </div>

                            <div className="flex flex-col md:flex-row md:justify-end gap-3 w-full md:col-span-2 border-t border-white/5 pt-6 md:border-0 md:pt-0">
                               <button 
                                 onClick={() => updateStatus(service.id, 'Entregue')} 
                                 className={`w-full md:w-auto px-6 py-4 md:py-2 text-[9px] font-black uppercase tracking-widest transition-all ${service.status === 'Entregue' ? 'bg-zinc-900 text-zinc-700 cursor-not-allowed' : 'bg-white text-black hover:bg-emerald-500'}`}
                                 disabled={service.status === 'Entregue'}
                               >
                                 ENTREGUE
                               </button>
                               <button onClick={() => handleDeleteService(service.id)} className="w-full md:w-12 h-14 md:h-auto flex items-center justify-center bg-red-950/20 text-red-500/40 hover:text-red-500 hover:bg-red-500/10 transition-all border border-red-500/10 md:border-0">
                                 <Trash2 size={16} />
                               </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'master' && currentUser.isAdmin && (
                  <motion.div key="master" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col border-t border-white/10">
                    <div className="py-4 px-6 bg-white/5 border-b border-white/10 flex justify-between items-center">
                      <span className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-400 italic">Gestão de Usuários</span>
                      <span className="text-[10px] font-black uppercase tracking-widest text-zinc-600">Ativos: {allUsers.filter(u => u.status === 'approved').length}</span>
                    </div>
                    {allUsers.filter(u => !u.isAdmin).map(user => (
                      <div key={user.uid} className="flex flex-col md:flex-row justify-between items-start md:items-center py-8 border-b border-white/10 hover:bg-white/5 px-6 gap-6 transition-colors">
                        <div className="flex flex-col">
                          <div className="flex items-center gap-2 mb-1">
                            <span className={`w-2 h-2 rounded-full ${user.status === 'approved' ? 'bg-emerald-500' : user.status === 'pending' ? 'bg-amber-500' : 'bg-red-500'}`} />
                            <h4 className="text-xl font-black uppercase tracking-tighter italic">{user.name}</h4>
                          </div>
                          <div className="flex flex-wrap gap-4 text-[9px] font-black text-zinc-500 uppercase tracking-widest">
                            <span>CPF: {user.cpf}</span>
                            <span className="text-white">WHATSAPP: {user.phone || 'NÃO INFORMADO'}</span>
                            <span>ID: {user.uid.slice(0, 8)}</span>
                          </div>
                        </div>
                          <div className="flex flex-wrap gap-3">
                            <button 
                              onClick={() => {
                                setTargetUserForPasswordChange(user);
                                setShowChangeUserPasswordModal(true);
                              }} 
                              className="px-4 py-2 border border-emerald-500/20 text-emerald-500 text-[8px] font-black uppercase tracking-widest hover:bg-emerald-500 hover:text-black transition-all"
                            >
                              ALTERAR SENHA
                            </button>
                            <button 
                              onClick={() => handleAdminResetPassword(user.email || '')} 
                              className="px-4 py-2 border border-amber-500/20 text-amber-500 text-[8px] font-black uppercase tracking-widest hover:bg-amber-500 hover:text-black transition-all"
                            >
                              ENVIAR E-MAIL RESET
                            </button>
                            <button onClick={() => setEditingUser(user)} className="px-4 py-2 border border-white/10 text-[8px] font-black uppercase tracking-widest hover:bg-white hover:text-black transition-all">EDITAR</button>
                            <button onClick={() => handleDeleteUser(user.uid)} className="px-4 py-2 border border-red-500/20 text-red-500 hover:bg-red-500 hover:text-black transition-all">EXCLUIR</button>
                          <button onClick={() => handleUpdateUserStatus(user.uid, user.status === 'approved' ? 'blocked' : 'approved')} className={`px-4 py-2 border text-[8px] font-black uppercase tracking-widest flex items-center gap-2 transition-all ${user.status === 'approved' ? 'border-red-500/20 text-red-500 bg-red-500/10 hover:bg-red-500 hover:text-black' : 'border-emerald-500/20 text-emerald-500 bg-emerald-500/10 hover:bg-emerald-500 hover:text-black'}`}>
                            {user.status === 'approved' ? <UserX size={12} /> : <UserCheck size={12} />}
                            {user.status === 'approved' ? 'BLOQUEAR' : 'APROVAR ACESSO'}
                          </button>
                        </div>
                      </div>
                    ))}
                  </motion.div>
                )}
                {activeTab === 'meu-extrato' && currentUser.role === 'employee' && (
                  <motion.div key="meu-extrato" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col gap-8 max-w-4xl mx-auto w-full">
                    <div className="flex justify-between items-end mb-8">
                      <div>
                        <h2 className="text-4xl font-black italic uppercase tracking-tighter">Meu Extrato</h2>
                        <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Acompanhe seus ganhos e vales</p>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] font-black text-zinc-600 uppercase tracking-widest block mb-1">Saldo Total a Receber</span>
                        <span className={`text-4xl font-black italic ${(employees[0]?.balance || 0) < 0 ? 'text-red-500' : 'text-emerald-500'}`}>
                          R$ {formatCurrency(employees[0]?.balance || 0)}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                       {/* Comissões */}
                       <div className="bg-zinc-950 border border-white/10">
                         <div className="p-4 border-b border-white/10 bg-zinc-900/50">
                           <h3 className="text-[10px] font-black uppercase tracking-widest italic flex items-center gap-2">
                             <CheckCircle2 size={14} className="text-emerald-500" /> Minhas Comissões
                           </h3>
                         </div>
                         <div className="max-h-[400px] overflow-y-auto">
                           {services.map(s => (
                             <div key={s.id} className="p-4 border-b border-white/5 last:border-0 flex justify-between items-center bg-zinc-950">
                               <div>
                                 <div className="text-[10px] font-black italic uppercase mb-1">{s.clientName}</div>
                                 <div className="text-[8px] font-bold text-zinc-600 uppercase tracking-widest">{s.status} // {s.deliveryDate || s.createdAt}</div>
                               </div>
                               <div className="text-right">
                                 <div className="text-xs font-black italic text-emerald-500">+ R$ {formatCurrency(s.commissionValue)}</div>
                                 <div className={`text-[6px] font-black uppercase px-2 py-0.5 rounded ${s.commissionStatus === 'paid' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'}`}>
                                   {s.commissionStatus === 'paid' ? 'PAGO' : 'AGUARDANDO'}
                                 </div>
                               </div>
                             </div>
                           ))}
                           {services.length === 0 && <div className="p-8 text-center text-zinc-700 text-[10px] font-black uppercase">Nenhum serviço vinculado.</div>}
                         </div>
                       </div>

                       {/* Vales */}
                       <div className="bg-zinc-950 border border-white/10">
                         <div className="p-4 border-b border-white/10 bg-zinc-900/50">
                           <h3 className="text-[10px] font-black uppercase tracking-widest italic flex items-center gap-2">
                             <TrendingDown size={14} className="text-red-500" /> Meus Vales / Adiantamentos
                           </h3>
                         </div>
                         <div className="max-h-[400px] overflow-y-auto">
                           {advances.map(a => (
                             <div key={a.id} className="p-4 border-b border-white/5 last:border-0 flex justify-between items-center bg-zinc-950">
                               <div>
                                 <div className="text-[10px] font-black italic uppercase mb-1">{a.description}</div>
                                 <div className="text-[8px] font-bold text-zinc-600 uppercase tracking-widest text-red-500/50">{a.date}</div>
                               </div>
                               <div className="text-right">
                                 <div className="text-xs font-black italic text-red-500">- R$ {formatCurrency(a.value)}</div>
                               </div>
                             </div>
                           ))}
                            {advances.length === 0 && <div className="p-8 text-center text-zinc-700 text-[10px] font-black uppercase">Nenhum vale registrado.</div>}
                         </div>
                       </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
        </AnimatePresence>
      </main>

      {/* --- Modals --- */}
      
      {/* Edit Service Modal */}
      {editingService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/90" onClick={() => setEditingService(null)} />
          <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-zinc-950 border border-white/20 p-12 relative w-full max-w-lg overflow-y-auto max-h-[90vh]">
            <h2 className="text-3xl font-black font-display uppercase italic mb-8">Editar Serviço #{editingService.id.slice(0, 5)}</h2>
            <form onSubmit={handleEditService} className="flex flex-col gap-4">
              <input 
                placeholder="NOME DO CLIENTE" 
                className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none transition-colors"
                value={editingService.clientName}
                onChange={e => setEditingService({...editingService, clientName: e.target.value})}
                required
              />
              <div className="grid grid-cols-2 gap-4">
                <input 
                  placeholder="CPF" 
                  className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none"
                  value={editingService.cpf}
                  onChange={e => setEditingService({...editingService, cpf: e.target.value})}
                />
                <input 
                  placeholder="TELEFONE" 
                  className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none"
                  value={editingService.phone}
                  onChange={e => setEditingService({...editingService, phone: e.target.value})}
                />
              </div>
              <input 
                placeholder="ENDEREÇO" 
                className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none"
                value={editingService.address}
                onChange={e => setEditingService({...editingService, address: e.target.value})}
              />
              <textarea 
                placeholder="DESCRIÇÃO" 
                className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none h-24"
                value={editingService.description}
                onChange={e => setEditingService({...editingService, description: e.target.value})}
                required
              />
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col gap-1">
                  <label className="text-[8px] font-black text-zinc-600 uppercase tracking-widest">Valor Total (R$)</label>
                  <input 
                    type="number"
                    className="bg-transparent border border-white/10 px-4 py-3 text-sm focus:border-white outline-none"
                    value={editingService.totalValue}
                    onChange={e => setEditingService({...editingService, totalValue: Number(e.target.value)})}
                    required
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[8px] font-black text-zinc-600 uppercase tracking-widest">Valor de Entrada (R$)</label>
                  <input 
                    type="number"
                    className="bg-transparent border border-white/10 px-4 py-3 text-sm focus:border-white outline-none"
                    value={editingService.downPayment || ''}
                    onChange={e => setEditingService({...editingService, downPayment: e.target.value === '' ? 0 : Number(e.target.value)})}
                  />
                </div>
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-[8px] font-black text-zinc-600 uppercase tracking-widest">Comissão do Funcionário (R$)</label>
                <input 
                  type="number"
                  className="bg-transparent border border-white/10 px-4 py-3 text-sm focus:border-white outline-none"
                  value={editingService.commissionValue}
                  onChange={e => setEditingService({...editingService, commissionValue: Number(e.target.value)})}
                  required
                />
              </div>
              <button className="bg-white text-black py-4 font-black uppercase text-[10px] tracking-widest mt-4 hover:invert transition-all">SALVAR ALTERAÇÕES</button>
            </form>
          </motion.div>
        </div>
      )}

      {/* New Service Modal */}
      {showNewServiceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/90" onClick={() => setShowNewServiceModal(false)} />
          <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-zinc-950 border border-white/20 p-12 relative w-full max-w-lg">
            <h2 className="text-3xl font-black font-display uppercase italic mb-8">Novo Cadastro de Serviço</h2>
            <form onSubmit={handleAddService} className="flex flex-col gap-4">
              <input 
                placeholder="NOME DO CLIENTE" 
                className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none transition-colors"
                value={newService.clientName}
                onChange={e => setNewService({...newService, clientName: e.target.value})}
                required
              />
              <div className="grid grid-cols-2 gap-4">
                <input 
                  placeholder="CPF" 
                  className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none"
                  value={newService.cpf}
                  onChange={e => setNewService({...newService, cpf: e.target.value})}
                />
                <input 
                  placeholder="TELEFONE" 
                  className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none"
                  value={newService.phone}
                  onChange={e => setNewService({...newService, phone: e.target.value})}
                />
              </div>
              <input 
                placeholder="ENDEREÇO" 
                className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none"
                value={newService.address}
                onChange={e => setNewService({...newService, address: e.target.value})}
              />
              <textarea 
                placeholder="DESCRIÇÃO DO SERVIÇO" 
                className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none h-32"
                value={newService.description}
                onChange={e => setNewService({...newService, description: e.target.value})}
                required
              />
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col gap-1">
                  <label className="text-[8px] font-black text-zinc-600 uppercase tracking-widest">Valor Total (R$)</label>
                  <input 
                    type="number"
                    className="bg-transparent border border-white/10 px-4 py-3 text-sm focus:border-white outline-none"
                    value={newService.totalValue ?? ''}
                    onChange={e => {
                      const val = e.target.value === '' ? undefined : Number(e.target.value);
                      setNewService({...newService, totalValue: val});
                      if(commissionType === 'percent') calculateCommission(val, commissionPercent);
                    }}
                    required
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[8px] font-black text-zinc-600 uppercase tracking-widest">Valor de Entrada (R$)</label>
                  <input 
                    type="number"
                    className="bg-transparent border border-white/10 px-4 py-3 text-sm focus:border-white outline-none"
                    value={newService.downPayment ?? ''}
                    onChange={e => setNewService({...newService, downPayment: e.target.value === '' ? undefined : Number(e.target.value)})}
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 gap-4">
                <div className="flex flex-col gap-1">
                  <div className="flex justify-between items-center">
                    <label className="text-[8px] font-black text-zinc-600 uppercase tracking-widest">Comissão do Funcionário</label>
                    <div className="flex gap-2">
                      <button type="button" onClick={() => setCommissionType('value')} className={`text-[8px] font-bold ${commissionType === 'value' ? 'text-white' : 'text-zinc-700'}`}>R$</button>
                      <button type="button" onClick={() => setCommissionType('percent')} className={`text-[8px] font-bold ${commissionType === 'percent' ? 'text-white' : 'text-zinc-700'}`}>%</button>
                    </div>
                  </div>
                  {commissionType === 'value' ? (
                    <input 
                      type="number"
                      className="bg-transparent border border-white/10 px-4 py-3 text-sm focus:border-white outline-none"
                      value={newService.commissionValue ?? ''}
                      onChange={e => setNewService({...newService, commissionValue: e.target.value === '' ? undefined : Number(e.target.value)})}
                      required
                    />
                  ) : (
                    <input 
                      type="number"
                      placeholder="%"
                      className="bg-transparent border border-white/10 px-4 py-3 text-sm focus:border-white outline-none"
                      value={commissionPercent ?? ''}
                      onChange={e => {
                        const p = e.target.value === '' ? undefined : Number(e.target.value);
                        setCommissionPercent(p);
                        calculateCommission(newService.totalValue, p);
                      }}
                      required
                    />
                  )}
                </div>
              </div>
              <button className="bg-white text-black py-4 font-black uppercase text-[10px] tracking-widest mt-4 hover:invert transition-all">SALVAR REGISTRO</button>
            </form>
          </motion.div>
        </div>
      )}

      {/* Edit Employee Modal */}
      {editingEmployee && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/90" onClick={() => setEditingEmployee(null)} />
          <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-zinc-950 border border-white/20 p-12 relative w-full max-sm:max-w-full max-w-sm">
            <h2 className="text-3xl font-black font-display uppercase italic mb-8">Editar Funcionário</h2>
            <form onSubmit={handleEditEmployee} className="flex flex-col gap-4">
              <input 
                placeholder="NOME COMPLETO" 
                className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none"
                value={editingEmployee.name}
                onChange={e => setEditingEmployee({...editingEmployee, name: e.target.value})}
                required
              />
              <input 
                placeholder="CPF (APENAS NÚMEROS)" 
                className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none"
                value={editingEmployee.cpf || ''}
                onChange={e => setEditingEmployee({...editingEmployee, cpf: e.target.value})}
                required
              />
              <input 
                placeholder="SENHA DE ACESSO" 
                type="text"
                className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none"
                value={editingEmployee.password || ''}
                onChange={e => setEditingEmployee({...editingEmployee, password: e.target.value})}
                required
              />
              <button className="bg-white text-black py-4 font-black uppercase text-[10px] tracking-widest mt-4 hover:invert transition-all">SALVAR ALTERAÇÕES</button>
            </form>
          </motion.div>
        </div>
      )}

      {/* New Employee Modal */}
      {showNewEmployeeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/90" onClick={() => setShowNewEmployeeModal(false)} />
          <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-zinc-950 border border-white/20 p-12 relative w-full max-w-sm">
            <h2 className="text-3xl font-black font-display uppercase italic mb-8">Novo Funcionário</h2>
            <form onSubmit={handleAddEmployee} className="flex flex-col gap-4">
              <input 
                placeholder="NOME COMPLETO" 
                className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none"
                value={newEmployeeName}
                onChange={e => setNewEmployeeName(e.target.value)}
                required
              />
              <input 
                placeholder="CPF (APENAS NÚMEROS)" 
                className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none"
                value={newEmployeeCPF}
                onChange={e => setNewEmployeeCPF(e.target.value)}
                required
              />
              <input 
                placeholder="SENHA DE ACESSO" 
                type="text"
                className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none"
                value={newEmployeePassword}
                onChange={e => setNewEmployeePassword(e.target.value)}
                required
              />
              <button className="bg-white text-black py-4 font-black uppercase text-[10px] tracking-widest mt-4 hover:invert transition-all">CADASTRAR</button>
            </form>
          </motion.div>
        </div>
      )}

      {/* Launch Vale Modal */}
      {launchingValeEmployeeId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/90" onClick={() => setLaunchingValeEmployeeId(null)} />
          <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-zinc-950 border border-white/20 p-8 sm:p-12 relative w-full max-w-[90%] sm:max-w-sm">
            <h2 className="text-2xl sm:text-3xl font-black font-display uppercase italic mb-6 sm:mb-8">Lançar Vale</h2>
            <div className="mb-6">
              <span className="text-[10px] font-black uppercase tracking-widest text-zinc-500">Funcionário</span>
              <p className="text-lg sm:text-xl font-black uppercase break-words">{employees.find(e => e.id === launchingValeEmployeeId)?.name}</p>
            </div>
            <form onSubmit={handleLaunchVale} className="flex flex-col gap-4">
              <input 
                type="number"
                placeholder="VALOR (R$)" 
                className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none w-full"
                value={valeAmount ?? ''}
                onChange={e => setValeAmount(e.target.value === '' ? undefined : Number(e.target.value))}
                required
              />
              <input 
                placeholder="DESCRIÇÃO (Motivo)" 
                className="bg-transparent border border-white/10 px-4 py-3 placeholder:text-zinc-700 text-sm focus:border-white outline-none w-full"
                value={valeDescription}
                onChange={e => setValeDescription(e.target.value)}
                required
              />
              <button className="bg-white text-black py-4 font-black uppercase text-[10px] tracking-widest mt-4 hover:invert transition-all w-full">CONFIRMAR LANÇAMENTO</button>
            </form>
          </motion.div>
        </div>
      )}

      {/* Statement Modal */}
      {viewingStatementEmployeeId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/95" onClick={() => setViewingStatementEmployeeId(null)} />
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-zinc-950 border border-white/10 p-6 sm:p-12 relative w-full max-w-2xl h-[85vh] sm:h-[80vh] flex flex-col">
            <div className="flex justify-between items-start mb-8 sm:mb-12">
              <div className="pr-10">
                <h2 className="text-3xl sm:text-4xl font-black font-display uppercase tracking-tight leading-none mb-2">EXTRATO</h2>
                <p className="text-zinc-500 font-black uppercase tracking-widest text-[9px] sm:text-[10px] break-words">{employees.find(e => e.id === viewingStatementEmployeeId)?.name}</p>
              </div>
              <button 
                onClick={() => setViewingStatementEmployeeId(null)}
                className="absolute right-4 top-4 sm:right-12 sm:top-12 w-10 h-10 border border-white/10 flex items-center justify-center hover:bg-white/5"
              >
                <X size={20} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto pr-2 sm:pr-4">
              <div className="flex flex-col border-t border-white/10">
                
                {/* Serviços em Aberto (Projeção) */}
                {services
                  .filter(s => (s.status === 'Pendente' || s.status === 'Em Produção') && s.responsibleId === viewingStatementEmployeeId)
                  .length > 0 && (
                  <div className="bg-white/5 px-3 sm:px-4 pt-6 pb-2 border-b border-white/10">
                    <div className="text-[8px] sm:text-[9px] font-black uppercase tracking-[0.3em] text-zinc-500 mb-4 italic">Serviços em Execução (Ganhos Futuros)</div>
                    {services
                      .filter(s => (s.status === 'Pendente' || s.status === 'Em Produção') && s.responsibleId === viewingStatementEmployeeId)
                      .map(s => (
                        <div key={s.id} className="py-3 border-b border-white/5 last:border-0 flex justify-between items-center opacity-60">
                          <div className="pr-4">
                            <div className="text-[10px] sm:text-xs font-bold uppercase tracking-tight break-words">{s.clientName} - {s.description}</div>
                            <div className="text-[7px] sm:text-[8px] font-black uppercase tracking-widest text-zinc-600">{s.status}</div>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className={`text-xs sm:text-sm font-black italic whitespace-nowrap ${s.commissionStatus === 'paid' ? 'text-emerald-500' : 'text-amber-500'}`}>
                              + R$ {formatCurrency(s.commissionValue)}
                            </div>
                            <button 
                              onClick={() => handleDeleteService(s.id)}
                              className="text-zinc-500 hover:text-red-500 transition-colors"
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        </div>
                      ))}
                  </div>
                )}

                {/* Serviços Finalizados (Entradas) */}
                <div className="mt-8 mb-2">
                  <div className="text-[8px] sm:text-[9px] font-black uppercase tracking-[0.3em] text-zinc-500 italic ml-2 sm:ml-4">Histórico de Comissões Realizadas</div>
                </div>
                {services
                  .filter(s => s.status === 'Finalizado' || s.status === 'Entregue')
                  .filter(s => s.responsibleId === viewingStatementEmployeeId)
                  .map(s => (
                    <div key={s.id} className="py-4 border-b border-white/5 flex justify-between items-center px-2 sm:px-4">
                      <div className="pr-4">
                        <div className="text-[8px] sm:text-[10px] font-black uppercase tracking-widest text-emerald-500 mb-1">COMISSÃO RECEBIDA</div>
                        <div className="text-xs sm:text-sm font-bold uppercase tracking-tight italic break-words">{s.clientName} - {s.description}</div>
                        <div className="text-[8px] sm:text-[9px] font-mono text-zinc-600">{s.deliveryDate}</div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className={`text-base sm:text-lg font-black whitespace-nowrap ${s.commissionStatus === 'paid' ? 'text-emerald-500' : 'text-amber-500'}`}>
                          + R$ {formatCurrency(s.commissionValue)}
                        </div>
                        <button 
                          onClick={() => handleDeleteService(s.id)}
                          className="text-zinc-600 hover:text-red-500 transition-colors"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}

                {/* Vales (Saídas) */}
                <div className="mt-8 mb-2">
                  <div className="text-[8px] sm:text-[9px] font-black uppercase tracking-[0.3em] text-zinc-500 italic ml-2 sm:ml-4">Histórico de Vales e Adiantamentos</div>
                </div>
                {advances
                  .filter(a => a.employeeId === viewingStatementEmployeeId)
                  .map(a => (
                    <div key={a.id} className="py-4 border-b border-white/5 flex justify-between items-center px-2 sm:px-4">
                      <div className="pr-4">
                        <div className="text-[8px] sm:text-[10px] font-black uppercase tracking-widest text-red-500 mb-1">VALE / ADIANTAMENTO</div>
                        <div className="text-xs sm:text-sm font-bold uppercase tracking-tight italic break-words">{a.description}</div>
                        <div className="text-[8px] sm:text-[9px] font-mono text-zinc-600">{a.date}</div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-base sm:text-lg font-black text-red-500 whitespace-nowrap">- R$ {formatCurrency(a.value)}</div>
                        <button 
                          onClick={() => handleDeleteAdvance(a.id)}
                          className="text-zinc-600 hover:text-red-500 transition-colors"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                
                {services.filter(s => s.responsibleId === viewingStatementEmployeeId && (s.status === 'Finalizado' || s.status === 'Entregue')).length === 0 && 
                 advances.filter(a => a.employeeId === viewingStatementEmployeeId).length === 0 && (
                  <div className="py-20 text-center text-zinc-700 italic font-medium text-xs sm:text-sm">Nenhuma movimentação registrada.</div>
                )}
              </div>
            </div>

            <div className="mt-auto pt-6 sm:pt-8 border-t border-white/20 flex justify-between items-end">
              <div className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-zinc-600">Saldo Atual</div>
              <div className={`text-2xl sm:text-4xl font-black italic ${
                (employees.find(e => e.id === viewingStatementEmployeeId)?.balance ?? 0) < 0 ? 'text-red-500' : 
                (employees.find(e => e.id === viewingStatementEmployeeId)?.balance ?? 0) > 0 ? 'text-emerald-500' : 'text-white'
              }`}>
                R$ {formatCurrency(employees.find(e => e.id === viewingStatementEmployeeId)?.balance ?? 0)}
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Assign Employee Modal */}
      {assigningServiceId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/95" onClick={() => setAssigningServiceId(null)} />
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-zinc-950 border border-white/10 p-12 relative w-full max-w-md">
            <h3 className="text-xl font-black font-display uppercase tracking-widest mb-8 border-b border-white/10 pb-4">Atribuir Responsável</h3>
            <div className="flex flex-col gap-2">
              <button 
                onClick={() => assignEmployee(assigningServiceId, '')}
                className="flex items-center gap-4 px-6 py-4 text-xs font-black uppercase tracking-widest text-zinc-600 hover:text-white hover:bg-white/5 transition-all text-left"
              >
                Remover Atribuição
              </button>
              {employees.length === 0 && (
                <div className="py-8 text-center text-zinc-500 font-black uppercase text-[10px] tracking-widest">
                  Nenhum funcionário cadastrado.
                </div>
              )}
              {employees.map(emp => (
                <button 
                  key={emp.id}
                  onClick={() => assignEmployee(assigningServiceId, emp.id)}
                  className="flex items-center gap-4 px-6 py-4 text-xs font-black uppercase tracking-widest hover:bg-white hover:text-black transition-all text-left"
                >
                  <User size={16} /> {emp.name}
                </button>
              ))}
            </div>
          </motion.div>
        </div>
      )}

      {/* Support floating button inside panel */}
      {currentUser.status === 'approved' && (
        <a 
          href="https://wa.me/5562996346075" 
          target="_blank"
          rel="noreferrer"
          className="fixed bottom-8 right-8 z-50 bg-white text-black w-14 h-14 rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-transform md:hidden"
        >
          <Phone size={24} />
        </a>
      )}

      {/* Footer / Status Bar */}
      <footer className="fixed bottom-0 right-0 p-4 hidden lg:block z-40">
        <div className="bg-zinc-900/80 backdrop-blur-md border border-white/10 px-6 py-2 rounded-full flex items-center gap-6">
          <a href="https://wa.me/5562996346075" className="flex items-center gap-2 hover:text-white transition-colors">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400 italic">SUPORTE TÉCNICO</span>
          </a>
          <div className="text-[10px] font-mono text-zinc-600 uppercase tracking-tighter">MODERNA.PRO_V2_SAAS</div>
        </div>
      </footer>
      {/* Edit User Modal */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/95 backdrop-blur-md" onClick={() => setEditingUser(null)} />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-zinc-950 border border-white/10 w-full max-w-xl relative z-10 overflow-hidden"
          >
            <div className="h-1 w-full bg-white" />
            <div className="p-8 md:p-12">
              <div className="flex justify-between items-center mb-10">
                <h2 className="text-3xl font-black uppercase tracking-tighter italic">Editar Usuário</h2>
                <button onClick={() => setEditingUser(null)} className="text-zinc-500 hover:text-white transition-colors"><X size={24} /></button>
              </div>
              
              <form onSubmit={handleUpdateUserDetails} className="flex flex-col gap-8">
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest italic">Nome do Titular / Empresa</label>
                  <input 
                    type="text" 
                    className="bg-zinc-900 border border-white/10 px-6 py-4 text-sm font-bold text-white outline-none focus:border-white uppercase"
                    value={editingUser.name}
                    onChange={e => setEditingUser({...editingUser, name: e.target.value})}
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="flex flex-col gap-2">
                    <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest italic">CPF</label>
                    <input 
                      type="text" 
                      className="bg-zinc-900 border border-white/10 px-6 py-4 text-sm font-bold text-white outline-none focus:border-white"
                      value={editingUser.cpf}
                      onChange={e => setEditingUser({...editingUser, cpf: e.target.value})}
                      required
                    />
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest italic">Telefone (WhatsApp)</label>
                    <input 
                      type="text" 
                      className="bg-zinc-900 border border-white/10 px-6 py-4 text-sm font-bold text-white outline-none focus:border-white"
                      value={editingUser.phone || ''}
                      onChange={e => setEditingUser({...editingUser, phone: e.target.value})}
                      required
                    />
                  </div>
                </div>

                <div className="bg-white/5 p-6 border border-white/5 mt-4">
                  <h4 className="text-[10px] font-black uppercase tracking-widest mb-2 text-zinc-500 italic">Gestão de Senha</h4>
                  <p className="text-[8px] font-bold text-zinc-600 uppercase leading-relaxed">
                    Por segurança, a alteração de senha deve ser solicitada pelo próprio usuário via "Esqueci minha senha" ou reset de fábrica via suporte.
                  </p>
                </div>

                <button 
                  type="submit"
                  className="w-full bg-white text-black py-6 font-black uppercase text-[12px] tracking-widest hover:invert transition-all mt-6"
                >
                  SALVAR ALTERAÇÕES
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      )}

      {/* Admin New User Modal */}
      {showAdminNewUserModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/95 backdrop-blur-md" onClick={() => setShowAdminNewUserModal(false)} />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-zinc-950 border border-white/10 w-full max-w-xl relative z-10 overflow-hidden"
          >
            <div className="h-1 w-full bg-blue-600" />
            <div className="p-8 md:p-12">
              <div className="flex justify-between items-center mb-10">
                <h2 className="text-3xl font-black uppercase tracking-tighter italic">Novo Cliente / Empresa</h2>
                <button onClick={() => setShowAdminNewUserModal(false)} className="text-zinc-500 hover:text-white transition-colors"><X size={24} /></button>
              </div>
              
              <form onSubmit={handleAdminCreateUser} className="flex flex-col gap-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="flex flex-col gap-2">
                    <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest italic">Nome / Empresa</label>
                    <input 
                      type="text" 
                      className="bg-zinc-900 border border-white/10 px-4 py-3 text-sm font-bold text-white outline-none focus:border-white uppercase"
                      value={adminNewUser.name}
                      onChange={e => setAdminNewUser({...adminNewUser, name: e.target.value})}
                      required
                    />
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest italic">CPF</label>
                    <input 
                      type="text" 
                      className="bg-zinc-900 border border-white/10 px-4 py-3 text-sm font-bold text-white outline-none focus:border-white"
                      value={adminNewUser.cpf}
                      onChange={e => setAdminNewUser({...adminNewUser, cpf: e.target.value})}
                      required
                    />
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest italic">Telefone (WhatsApp)</label>
                  <input 
                    type="text" 
                    className="bg-zinc-900 border border-white/10 px-4 py-3 text-sm font-bold text-white outline-none focus:border-white"
                    value={adminNewUser.phone}
                    onChange={e => setAdminNewUser({...adminNewUser, phone: e.target.value})}
                    required
                  />
                </div>

                <div className="flex flex-col gap-2">
                  <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest italic">E-mail de Acesso</label>
                  <input 
                    type="email" 
                    className="bg-zinc-900 border border-white/10 px-4 py-3 text-sm font-bold text-white outline-none focus:border-white"
                    value={adminNewUser.email}
                    onChange={e => setAdminNewUser({...adminNewUser, email: e.target.value})}
                    required
                  />
                </div>

                <div className="flex flex-col gap-2">
                  <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest italic">Definir Senha Inicial</label>
                  <input 
                    type="text" 
                    className="bg-zinc-900 border border-white/10 px-4 py-3 text-sm font-bold text-white outline-none focus:border-white"
                    value={adminNewUser.password}
                    onChange={e => setAdminNewUser({...adminNewUser, password: e.target.value})}
                    required
                  />
                </div>

                <div className="bg-blue-900/20 p-4 border border-blue-500/10 mt-2">
                  <p className="text-[9px] font-bold text-blue-400 uppercase leading-relaxed tracking-wider">
                    O USUÁRIO SERÁ CRIADO COM STATUS <span className="font-black text-white underline">LIBERADO (APPROVED)</span> AUTOMATICAMENTE E PODERÁ ENTRAR NO SISTEMA IMEDIATAMENTE.
                  </p>
                </div>

                <button 
                  type="submit"
                  className="w-full bg-blue-600 text-white py-5 font-black uppercase text-[12px] tracking-widest hover:bg-blue-500 transition-all mt-4"
                >
                  CADASTRAR E ATIVAR AGORA
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      )}
      {showChangePasswordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/95 backdrop-blur-md" onClick={() => setShowChangePasswordModal(false)} />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-zinc-950 border border-white/10 w-full max-w-sm relative z-10 overflow-hidden"
          >
            <div className="h-1 w-full bg-emerald-600" />
            <div className="p-8">
              <div className="flex justify-between items-center mb-8">
                <h2 className="text-2xl font-black uppercase tracking-tighter italic text-emerald-500">Alterar Senha</h2>
                <button onClick={() => setShowChangePasswordModal(false)} className="text-zinc-500 hover:text-white transition-colors"><X size={20} /></button>
              </div>
              
              <form onSubmit={handleUpdatePassword} className="flex flex-col gap-6">
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest italic">Nova Senha</label>
                  <div className="relative">
                    <input 
                      type={showPassword ? "text" : "password"} 
                      className="w-full bg-zinc-900 border border-white/10 px-4 py-3 text-sm font-bold text-white outline-none focus:border-white"
                      value={newPassword}
                      onChange={e => setNewPassword(e.target.value)}
                      required
                    />
                    <button 
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest italic">Confirmar Nova Senha</label>
                  <input 
                    type={showPassword ? "text" : "password"} 
                    className="bg-zinc-900 border border-white/10 px-4 py-3 text-sm font-bold text-white outline-none focus:border-white"
                    value={confirmNewPassword}
                    onChange={e => setConfirmNewPassword(e.target.value)}
                    required
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full bg-emerald-600 text-white py-4 font-black uppercase text-[12px] tracking-widest hover:bg-emerald-500 transition-all shadow-lg shadow-emerald-900/20"
                >
                  ATUALIZAR SENHA AGORA
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      )}
      {showChangeUserPasswordModal && targetUserForPasswordChange && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/95 backdrop-blur-md" onClick={() => {
            setShowChangeUserPasswordModal(false);
            setTargetUserForPasswordChange(null);
          }} />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-zinc-950 border border-white/10 w-full max-w-sm relative z-10 overflow-hidden"
          >
            <div className="h-1 w-full bg-blue-600" />
            <div className="p-8">
              <div className="flex justify-between items-center mb-8">
                <h2 className="text-2xl font-black uppercase tracking-tighter italic text-blue-500">Alterar Senha de Cliente</h2>
                <button onClick={() => {
                  setShowChangeUserPasswordModal(false);
                  setTargetUserForPasswordChange(null);
                }} className="text-zinc-500 hover:text-white transition-colors"><X size={20} /></button>
              </div>
              
              <div className="mb-6">
                <span className="text-[10px] font-black uppercase tracking-widest text-zinc-500">Usuário:</span>
                <p className="text-lg font-black uppercase italic">{targetUserForPasswordChange.name}</p>
                <p className="text-[9px] text-zinc-600 font-mono">{targetUserForPasswordChange.email}</p>
              </div>

              <form onSubmit={handleChangeUserPassword} className="flex flex-col gap-6">
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest italic">Nova Senha para o Cliente</label>
                  <div className="relative">
                    <input 
                      type={showPassword ? "text" : "password"} 
                      className="w-full bg-zinc-900 border border-white/10 px-4 py-3 text-sm font-bold text-white outline-none focus:border-white"
                      value={newUserPassword}
                      onChange={e => setNewUserPassword(e.target.value)}
                      required
                    />
                    <button 
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                <button 
                  type="submit"
                  className="w-full bg-blue-600 text-white py-4 font-black uppercase text-[12px] tracking-widest hover:bg-blue-500 transition-all shadow-lg shadow-blue-900/20"
                >
                  FORÇAR NOVA SENHA
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
